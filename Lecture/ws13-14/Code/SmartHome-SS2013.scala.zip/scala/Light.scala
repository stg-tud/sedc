package srp.scala

class Light { def turnOn() { /*...*/ }; def turnOff() { /*...*/ }; }
