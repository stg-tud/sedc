package srp.scala
package r1

// Possible extension...

trait Estate extends Base {

    trait Garage extends Location
}

trait LightedAndDimmedEstate extends LightedAndDimmed with Estate {

    trait Garage extends super.Garage with super[LightedAndDimmed].Location
}

object MyLightedAndDimmedEstate extends LightedAndDimmedEstate {

    type location = Location
    type room = Room
    type floor = Floor
    type house = House

    def createRoom(): room = new Room { var lights: List[Light] = Nil; var shutters: List[Shutter] = Nil }
    def createFloor(rooms: List[room]): floor = new Floor { val locations = rooms }
    def createHouse(floors: List[floor]): house = new House { val locations = floors }

    class Garage(val lights: List[Light] = Nil, val shutters: List[Shutter] = Nil) extends super.Garage

    val room = createRoom()
    room.turnLightsOn
    room.turnLightsOff

    val garage = new Garage(Nil, Nil)
    garage.turnLightsOff
    garage.turnLightsOn
    
    val h = buildHouse("three floors with 6 rooms each")
    h.lights
    h.shutters
    h.locations
    h.turnLightsOn
}


