package srp.scala
package r1

import srp.scala.Light
import srp.scala.Shutter

trait Base {

    trait Location {}
    type location <: Location

    trait Room extends Location 
    type room <: Room
    def createRoom(): room

    trait CompositeLocation[L <: Location] extends Location {
        def locations: List[L]
    }

    trait Floor extends CompositeLocation[room]
    type floor <: Floor
    def createFloor(locations: List[room]): floor

    trait House extends CompositeLocation[floor]
    type house <: House
    def createHouse(locations: List[floor]): house

    def buildHouse(specification: String): house = {
        // imagine to parse the specification...
        createHouse(List(createFloor(List(createRoom()))))
    }
}

object Main extends App {

    object BasicHome extends Base {
        type location = Location
        type room = Room
        type floor = Floor
        type house = House

        def createRoom(): room = new Room {}
        def createFloor(rooms: List[room]): floor = new Floor { val locations = rooms }
        def createHouse(floors: List[floor]): house = new House { val locations = floors }

    }

    val house = BasicHome.buildHouse("two floors with 4 rooms each");
}