package srp.scala
package r1

trait Dimmed extends Base {

    trait Location extends super.Location {
        def shutters(): List[Shutter]
    }
    type location <: Location

    trait Room extends super.Room with Location
    type room <: Room

    trait CompositeLocation[L <: Location] extends super.CompositeLocation[L] with Location {
        def shutters: List[Shutter] = locations.flatMap(_.shutters())
    }

    trait Floor extends super.Floor with CompositeLocation[room]
    type floor <: Floor

    trait House extends super.House with CompositeLocation[floor]
    type house <: House
}