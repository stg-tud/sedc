package srp.scala
package r1

trait LightedAndDimmed extends Lighted with Dimmed {

    trait Location extends super[Lighted].Location with super[Dimmed].Location
    type location <: Location

    trait Room extends super[Lighted].Room with super[Dimmed].Room with Location
    type room <: Room

    trait CompositeLocation[L <: Location]
        extends super[Lighted].CompositeLocation[L]
        with super[Dimmed].CompositeLocation[L]
        with Location

    trait Floor extends super[Lighted].Floor with super[Dimmed].Floor with CompositeLocation[room]
    type floor <: Floor

    trait House extends super[Lighted].House with super[Dimmed].House with CompositeLocation[floor]
    type house <: House

}

object LightedAndDimmedBuilding extends LightedAndDimmed with App {

    type location = Location
    type room = Room
    type floor = Floor
    type house = House

    def createRoom(): room = new Room { var lights: List[Light] = Nil; var shutters: List[Shutter] = Nil }

    def createFloor(rooms: List[room]): floor = new Floor { val locations = rooms }

    def createHouse(floors: List[floor]): house = new House { val locations = floors }

    println("We can now create lighted and dimmed buildings!")

    val r1 = createRoom()
    val l = r1.lights
    val s = r1.shutters
    println(l+" "+s)

    var r2 = createRoom()

    val f = createFloor(List(r1, r2))
    println(f.locations+" "+f.lights+" "+f.shutters)
    val h = buildHouse("three floors with 6 rooms each")
    h.lights
    h.shutters
    h.locations
    h.turnLightsOn
}
