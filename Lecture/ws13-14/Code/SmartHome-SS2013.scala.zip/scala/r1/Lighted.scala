package srp.scala
package r1

trait Lighten {
    def lights(): List[Light]
}

trait Lighted extends Base {

    trait Location extends super.Location with Lighten {

        def turnLightsOn = lights.foreach(_.turnOn())

        def turnLightsOff = lights.foreach(_.turnOff())

    }
    type location <: Location

    trait Room extends super.Room with Location
    type room <: Room

    trait CompositeLocation[L <: Location] extends super.CompositeLocation[L] with Location {
        def lights: List[Light] = locations.flatMap(_.lights())
    }

    trait Floor extends super.Floor with CompositeLocation[room]
    type floor <: Floor

    trait House extends super.House with CompositeLocation[floor]
    type house <: House
}

object Enlighted extends Lighted with App {

    type location = Location
    type room = Room
    type floor = Floor
    type house = House

    def createRoom(): room = new Room { var lights: List[Light] = Nil }

    def createFloor(rooms: List[room]): floor = new Floor { val locations = rooms }

    def createHouse(floors: List[floor]): house = new House { val locations = floors }

    val r1 = createRoom()
    val r2 = createRoom()

    val f = createFloor(List(r1, r2))

    println(f.locations)
    println(f.lights)

    val l: Lighten = buildHouse("two floors with 4 rooms each")
    l.lights
}