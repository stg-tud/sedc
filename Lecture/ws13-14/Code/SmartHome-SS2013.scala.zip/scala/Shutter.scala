package srp.scala

class Shutter { def raise() { /*...*/ }; def lower() { /*...*/ }; }
