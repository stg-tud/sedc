package ex05

trait Cards {
  val deck: Seq[Card]
  type Card <: TCard

  trait TCard {
    def name: String
  }

  val cardOrdering: Ordering[Card]
}

trait SuitedCards {
  val suits: Seq[???]
  val suitOrdering: Ordering[???]
}

trait RankedCards {
  val ranks: Seq[???]
  val rankOrdering: Ordering[???]
}