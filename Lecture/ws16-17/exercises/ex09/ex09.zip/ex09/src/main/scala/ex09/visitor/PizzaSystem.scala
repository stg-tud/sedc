package ex09.visitor

/**
  * Instances of this class represent orders of a given client, with an index for the register system,
  * and a list of ordered items.
  */
case class Order(client: String, index: Int, val items: Product*) {
  def invoke(v: ProductVisitor) = ???
}

/**
  * A visitor that can visit all items in an order.
  */
trait ProductVisitor {
  def startVisit(p: Pizza)

  def endVisit(p: Pizza)

  // ...
}
