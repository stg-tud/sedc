package ex09.visitor

object PizzaTest extends App {
  val fp = FamilyPizza(SalamiPizza + Cheese + Cheese + Salami + Ham)
  println(fp)
}