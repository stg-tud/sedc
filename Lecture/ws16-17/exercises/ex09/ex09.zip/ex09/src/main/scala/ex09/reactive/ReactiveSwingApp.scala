package ex09.reactive

import scala.swing.{SimpleSwingApplication, Swing}

/**
 * Utility class to run REScala applications on the Swing thread.
 */
abstract class ReactiveSwingApp extends SimpleSwingApplication with App {
  override def main(args: Array[String]) = {
    Swing.onEDT { super[App].main(args) }
    super[SimpleSwingApplication].main(args)
  }
}