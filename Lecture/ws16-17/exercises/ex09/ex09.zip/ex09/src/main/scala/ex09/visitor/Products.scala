package ex09.visitor

import Price._

/**
 * The base trait for all items that can be ordered in the store.
 */
trait Product {
  def name: String
  def price: Price
}

abstract class FranchiseProduct(val name: String, val price: Price) extends Product

object Shirt extends FranchiseProduct("TastyPizza T-Shirt", 21 eur 99)
object Mug extends FranchiseProduct("TastyPizza Mug", 4 eur 99)

abstract class Consumable extends Product {
  def calories: Int
}

abstract class Drink(val name: String, val price: Price, val calories: Int, val isAlcoholic: Boolean) extends Consumable

object Lemonade extends Drink("Lemonade", 1 eur 29, 128, false)
object Water extends Drink("Water", 1 eur 29, 0, false)
object Wine extends Drink("Wine", 7 eur 49, 607, true)

trait Pizza extends Consumable {
  def +(t: Topping): Pizza = ToppedPizza(this, t)
  def toppings: Seq[Topping]
}

case class ToppedPizza(basePizza: Pizza, additionalTopping: Topping) extends Pizza {
  def name = basePizza.name
  def price = basePizza.price + additionalTopping.price
  def calories = basePizza.calories + additionalTopping.calories
  def toppings = basePizza.toppings :+ additionalTopping
}

case class FamilyPizza(basePizza: Pizza) extends Pizza {
  def name = basePizza.name + " (family size)"
  def price = basePizza.price + (4 eur 15)
  def calories = (basePizza.calories * 1.95).toInt
  def toppings = basePizza.toppings
}

abstract class NamedPizza(val name: String, val price: Price, val calories: Int, val toppings: Seq[Topping]) extends Pizza

object PizzaMargherita extends NamedPizza("Pizza Margherita", 4 eur 99, 1104, Seq(TomatoSauce, Cheese))
object HawaiianPizza extends NamedPizza("Hawaiian Pizza", 6 eur 49, 1024, Seq(TomatoSauce, Cheese, Ham, Pineapple))
object SalamiPizza extends NamedPizza("Salami Pizza", 5 eur 99, 1160, Seq(TomatoSauce, Cheese, Salami))

abstract class Topping(val name: String, val price: Price, val calories: Int) extends Consumable

case object TomatoSauce extends Topping("Tomato Sauce", 0 eur 0, 0)
case object Cheese extends Topping("Cheese", 0 eur 69, 92)
case object Salami extends Topping("Salami", 0 eur 99, 86)
case object Ham extends Topping("Ham", 0 eur 79, 35)
case object Pineapple extends Topping("Pineapple", 0 eur 69, 24)
case object Onions extends Topping("Onions", 0 eur 99, 22)