package ex09.reactive

import java.util.concurrent.TimeUnit

import scala.language.implicitConversions

object Time {
  /**
    * With this implicit conversion in scope, we can write, e.g., `(1 secs)` or equivalently `1.secs`
    */
  implicit def long2TimeOps(t: Long): LongTimeOps = new LongTimeOps(t)

  /**
    * With this implicit conversion in scope, we can write, e.g., `(1.5 secs)`
    */
  implicit def double2TimeOps(t: Double): DoubleTimeOps = new DoubleTimeOps(t)
}

/**
  * Exposes methods to conveniently create time objects from Long values.
  */
class LongTimeOps(val t: Long) extends AnyVal {
  def nsecs: Time = Time(t)

  def msecs: Time = Time(t * 1000000)

  def secs: Time = Time(t * 1000000000)
}

/**
  * Exposes methods to conveniently create time objects from Double values.
  */
class DoubleTimeOps(val t: Double) extends AnyVal {
  def msecs: Time = Time((t * 10e6).toLong)

  def secs: Time = Time((t * 10e9).toLong)
}

/**
  * Instances of this class represent times. Stores nanoseconds internally.
  * Provides common operators to do arithmetic with times.
  */
case class Time(val nanos: Long) extends AnyVal {
  def +(that: Time): Time = Time(this.nanos + that.nanos)

  def -(that: Time): Time = Time(this.nanos - that.nanos)

  def *(d: Long): Time = Time(nanos * d)

  def *(d: Double): Time = Time((nanos * d).toLong)

  def /(d: Long): Time = Time(nanos / d)

  def /(d: Double): Time = Time((nanos / d).toLong)

  def /(t: Time): Double = nanos.toDouble / t.nanos

  def inSeconds: Long = TimeUnit.SECONDS.convert(nanos, TimeUnit.NANOSECONDS)
}