package ex09.reactive

import ex09.reactive.Time._
import rescala._

import scala.language.implicitConversions

/**
 * Clamping could alternatively be modeled as simple closures Double => Double.
 */
abstract class Policy {
  def clamp(v: Double): Double
}

object Once extends Policy {
  def clamp(v: Double): Double =
    if (v > 1) 1.0
    else if (v < 0) 0.0
    else v
}

object Repeat extends Policy {
  def clamp(v: Double): Double = v % 1.0
}

object Bounce extends Policy {
  def clamp(v: Double): Double = 1 - Math.abs(v % 2.0 - 1)
}

object Animation {
  def animate(f: Double => Double): Animation = new Animation(f)
  
  implicit def int2PathOps(x: Int): PathOps = new PathOps(x)

  class PathOps(val x: Int) extends AnyVal {
    def ->>(y: Int): Path = k => x + (y - x) * k
  }
  
  type Path = Double => Double
}

/**
 * An instances of this class represents a one dimensional animation of a Double value.
 */
class Animation(f: Double => Double, time: Time = 1.secs, policy: Policy = Once) {
  def in(t: Time): Animation = new Animation(f, t, policy)
  def repeat: Animation = new Animation(f, time, Repeat)
  def bounce: Animation = new Animation(f, time, Bounce)

  def start: Signal[Double] = {
    val t = Clock.time
    Signal {
      f(policy.clamp(t() / time))
    }
  }
}





