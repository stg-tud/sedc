package ex09.reactive

import java.awt.event.{ActionEvent, ActionListener}
import javax.swing.Timer

import rescala._
import Time._

import scala.language.postfixOps

/**
 * A utility class providing timer events and signals.
 */
object Clock {

  private val timer = new Timer(10, new ActionListener {
    var t0 = -1L
    def actionPerformed(e: ActionEvent): Unit = {
      // Initialize t0 here, since the first event sometimes takes a while to get through the Swing queue.
      // This simply reduces stutter.
      if (t0 < 0) t0 = e.getWhen
      val t = e.getWhen - t0
      ticks(t msecs)
    }
  })

  timer.start()

  /**
   * An event that emits time stamps every few milliseconds, starting at 0 at program startup (roughly). 
   * This, or the signal below, can be used for animation.
   */
  val ticks = Evt[Time]()

  /**
    * A signal holding the time since program startup. It is updated often enough to be used for animation.
    */
  val time: Signal[Time] = ticks.latest(0L nsecs)

}