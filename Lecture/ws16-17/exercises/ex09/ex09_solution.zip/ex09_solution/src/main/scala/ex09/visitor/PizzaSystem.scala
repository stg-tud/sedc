package ex09.visitor

import Price._

case class Order(val items: Product*) {
  def invoke(v: ProductVisitor) = items foreach { _ accept v }
}

trait ProductVisitor {
  def startVisit(p: Pizza)
  def endVisit(p: Pizza)
  def visit(p: Topping)
  def visit(d: Drink)
  def visit(p: FranchiseProduct)
}