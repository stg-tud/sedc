package ex09.reactive

import java.awt.{Color, Dimension, Graphics2D}

import rescala._
import Animation._
import Time._

import scala.language.postfixOps
import scala.swing.{MainFrame, Panel}


object ReactiveAnimation extends ReactiveSwingApp {
  val Width = 700
  val Height = 600
  val Size = 20

  def top = new MainFrame {
    title = "Reactive Animations"
    resizable = false
    val panel = new Panel {
      preferredSize = new Dimension(Width, Height)
          
      // Your animation signals go here:
      val lineX = (animate(100 ->> 300) in (2 secs) repeat).start

      val sineX = (animate(100 ->> 400) in (2 secs) bounce).start
      val sineY = (animate(x => 200 + math.sin(x * 10) * 50) in (2 secs) bounce).start

      val circleX = (animate(x => 400 + math.cos(2 * x * math.Pi) * 50) in (10 secs) repeat).start
      val circleY = (animate(x => 400 + math.sin(2 * x * math.Pi) * 50) in (10 secs) repeat).start

      // setup and redraw code
      val stateChanged = Clock.ticks
      stateChanged += { _ => repaint() }

      val time = Signal { Clock.time().inSeconds + "s running..." }

      override def paintComponent(g: Graphics2D) {
        super.paintComponent(g)
        g.setColor(Color.DARK_GRAY)
        g.drawString(time.now, 10, 20)

        // Drawing goes here
        g.fillOval(lineX.now.toInt, 100, Size, Size)
        g.fillOval(sineX.now.toInt, sineY.now.toInt, Size, Size)
        g.fillOval(circleX.now.toInt, circleY.now.toInt, Size, Size)
      }
    }
    contents = panel
  }
}