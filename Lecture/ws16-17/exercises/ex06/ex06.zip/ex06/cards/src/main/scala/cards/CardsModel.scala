package cards

import VirtualClasses._

import scala.util.Random

@family class CardsModel {

  @virtual abstract class Cards {
    def deck: Seq[Card]
    val cardOrdering: Ordering[Card]
  }

  @virtual abstract class Card {
    def name: String

    override def toString: String = name
  }
}

object CardGame extends App {
  
}
