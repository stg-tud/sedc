package caesarj

import VirtualClasses._
import specs.UnitSpec

class Test6 extends UnitSpec {
  "Test type inheritance of outer classes" should "work" in {
    
  }
}
