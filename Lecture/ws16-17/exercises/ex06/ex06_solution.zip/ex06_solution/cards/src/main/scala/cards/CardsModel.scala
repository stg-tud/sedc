package cards

import VirtualClasses._

import scala.util.Random

@family class CardsModel {

  @virtual abstract class Cards {
    def deck: Seq[Card]
    val cardOrdering: Ordering[Card]
  }

  @virtual abstract class Card {
    def name: String

    override def toString: String = name
  }
}

class Suit(val name: String)

@family class SuitedCards extends CardsModel {

  @virtual override abstract class Cards {
    val suits: Seq[Suit]
    val suitOrdering: Ordering[Suit]
  }

  @virtual override abstract class Card {
    def suit: Suit
  }

}

@family class FrenchSuitedCards extends SuitedCards {

  @virtual override abstract class Cards {
    val suits: Seq[Suit] = Seq(Clubs, Diamonds, Hearts, Spades)
  }

  object Clubs extends Suit("C")

  object Diamonds extends Suit("D")

  object Hearts extends Suit("H")

  object Spades extends Suit("S")
}

class Rank(val name: String)

@family class RankedCards extends CardsModel {

  @virtual override abstract class Cards {
    val ranks: Seq[Rank]
    val rankOrdering: Ordering[Rank]
  }

  @virtual override abstract class Card {
    def rank: Rank
  }
}

@family class PiquetRankedCards extends RankedCards {

  @virtual override abstract class Cards {
    val ranks: Seq[Rank] = Seq(Seven, Eight, Nine, Ten, Jack, Queen, King, Ace)
  }

  object Seven extends Rank("7")
  object Eight extends Rank("8")
  object Nine extends Rank("9")
  object Ten extends Rank("10")
  object Jack extends Rank("J")
  object Queen extends Rank("Q")
  object King extends Rank("K")
  object Ace extends Rank("A")
}

@family class FullRankedCards extends RankedCards {

  @virtual override abstract class Cards {
    val ranks: Seq[Rank] = Seq(Two, Three, Four, Five, Six, Seven, Eight, Nine, Ten, Jack, Queen, King, Ace)
  }

  object Two extends Rank("2")
  object Three extends Rank("3")
  object Four extends Rank("4")
  object Five extends Rank("5")
  object Six extends Rank("6")
  object Seven extends Rank("7")
  object Eight extends Rank("8")
  object Nine extends Rank("9")
  object Ten extends Rank("10")
  object Jack extends Rank("J")
  object Queen extends Rank("Q")
  object King extends Rank("K")
  object Ace extends Rank("A")
}


@family class SuitedAndRankedCards extends SuitedCards with RankedCards {

  @virtual override abstract class Cards {
    def deck: Seq[Card] = for(s <- suits; r <- ranks) yield Card(s, r)

    val cardOrdering = new Ordering[Card] {
      def compare(x: Card, y: Card): Int = {
        val ro = rankOrdering.compare(x.rank, y.rank)
        if (ro == 0) suitOrdering.compare(x.suit, y.suit)
        else ro
      }
    }

  }

  @virtual override class Card(val suit: Suit, val rank: Rank) {
    def name: String = rank.name + " of " + suit.name
  }
}

@family class FullFrenchSuitedCards extends SuitedAndRankedCards with FrenchSuitedCards with FullRankedCards {

}

@family class Game extends CardsModel {
  var players: List[Player] = List()

  def currentPlayer = players.head

  def nextPlayer = {
    players = (players.tail :+ players.head)
    players.head
  }

  @virtual abstract class Player(val name:String) {
    var cards: Seq[Card] = Seq()

    def play(): Option[Card]

    def drawCard(c: Card) {
      cards = c +: cards
    }

    override def toString() = name
  }

}

@family class MauMauGame extends FullFrenchSuitedCards with Game {

  val cards = Cards()

  def validPlay(play: Card): Boolean =
    cards.suitOrdering.equiv(top.suit, play.suit) || cards.rankOrdering.equiv(top.rank, play.rank)

  @virtual override class Cards {
    val rankOrdering: Ordering[Rank] = new Ordering[Rank] {
      val ord = Seq(Two, Three, Four, Five, Six, Seven, Eight, Nine, Ten, Jack, Queen, King, Ace)
      def compare(x: Rank, y: Rank): Int = {
        ord.indexOf(x) - ord.indexOf(y)
      }
    }
    val suitOrdering: Ordering[Suit] = new Ordering[Suit] {
      val ord = Seq(Clubs, Spades, Hearts, Diamonds)
      def compare(x: Suit, y: Suit): Int = {
        ord.indexOf(x) - ord.indexOf(y)
      }
    }
  }


  @virtual class AlwaysFirstCardPlayer(val name:String) extends Player {
    def play(): Option[Card] = {
      Some(cards.head)
    }
  }

  @virtual class NoCheater(val name:String) extends Player {
    def play(): Option[Card] = {
      val possibleCards = cards.filter { c => validPlay(c) }
      if (possibleCards.isEmpty) None else Some(possibleCards.head)
    }
  }

  var drawingStack: List[Card] = Random.shuffle(cards.deck.toList)
  var playedStack: List[Card] = drawCard :: List()

  def drawCard: Card = {
    val card = drawingStack.head
    drawingStack = drawingStack.drop(1)
    card
  }

  def dealCard(p: Player) {
    p.drawCard(drawCard)
  }

  def playCard(c: Card) = {
    playedStack = c +: playedStack
    checkSpecials(c, nextPlayer)
  }

  def checkSpecials(c: Card, next: Player) {
    if (c.rank == Eight) {
      next.drawCard(drawCard); next.drawCard(drawCard)
    }
    if (c.rank == King) {
      players = players.reverse
    }
  }

  def top = playedStack.head

  def playersTurn(p: Player) {
    val playedCard = p.play()
    if (playedCard.isEmpty || !validPlay(playedCard.get)) {
      dealCard(p)
    } else {
      playCard(playedCard.get)
    }
  }

}

object MauMau extends App {
  println("Mau Mau2")

  val m = MauMauGame()
  println(m.cards)
  println(m.top)

  m.players = List(m.AlwaysFirstCardPlayer("Ready Player 1"),m.AlwaysFirstCardPlayer("Bob"))
  val cp = m.nextPlayer
  println(cp.cards)
  m.dealCard(cp)
  println(cp.cards)
  println(m.nextPlayer)

  val m2 = MauMauGame()

  // These should not work, as not from the same family...
  //m2.dealCard(cp)
  //m2.players = m.players
}