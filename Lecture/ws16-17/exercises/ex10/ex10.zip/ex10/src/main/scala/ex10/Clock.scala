package ex10

import java.util.concurrent.{Executors, ScheduledFuture, TimeUnit}

import rescala._

import scala.language.postfixOps

class Clock {

  private val scheduler = Executors.newScheduledThreadPool(1)
  private var tickHandle: ScheduledFuture[_] = _

  def start(speed: Long): Unit = {
    tickHandle = scheduler.scheduleAtFixedRate(() => {
      tick.fire()
    }, 1, speed, TimeUnit.MILLISECONDS)
  }

  def start(): Unit = {
    start(1000)
  }

  def stop(): Unit = {
    tickHandle.cancel(true)
    scheduler.shutdown()
  }

  private val tick: Evt[Unit] = Evt[Unit]()
  private val numTicks = tick.count

  val seconds: Signal[Int] = ???
  val minutes: Signal[Int] = ???
  val hours: Signal[Int] = ???
  val day: Signal[Int] = ???
  val secondsOfDay: Signal[Int] = ???
}