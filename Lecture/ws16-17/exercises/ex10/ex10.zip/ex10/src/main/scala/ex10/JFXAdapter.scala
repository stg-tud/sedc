package ex10

import scalafx.beans.property.{BooleanProperty, DoubleProperty, Property, StringProperty}
import rescala._

import scalafx.application.Platform


object JFXAdapter {

  implicit class JFXAdapterImplicits[T, J](p: Property[T, J]) {

    def toSignal: Signal[T] = {
      val v = Var(p.value)
      p.onChange { (_, _, _) => v.set(p.value) }
      v
    }
  }

  implicit class SignalToStringProperty[T](s: Signal[T])(implicit ev: T =:= String) {
    def toProperty: StringProperty = {
      val p = StringProperty(ev(s.now))
      s.changed += { v =>
        Platform.runLater(p.update(ev(v)))
      }
      p
    }
  }

  implicit class SignalToDoubleProperty[T](s: Signal[T])(implicit ev: T =:= Double) {
    def toProperty: DoubleProperty = {
      val p = DoubleProperty(ev(s.now))
      s.changed += { v =>
        Platform.runLater(p.update(ev(v)))
      }
      p
    }
  }

  implicit class SignalToBooleanProperty[T](s: Signal[T])(implicit ev: T =:= Boolean) {
    def toProperty: BooleanProperty = {
      val p = BooleanProperty(ev(s.now))
      s.changed += { v =>
        Platform.runLater(p.update(ev(v)))
      }
      p
    }
  }
}
