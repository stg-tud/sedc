package ex10

import scalafx.Includes.handle
import scalafx.application.JFXApp.PrimaryStage
import scalafx.application.{JFXApp, Platform}
import scalafx.scene.Scene

object Main extends JFXApp {

  // TODO: Instantiate your Smart Home here

  stage = new PrimaryStage {

    width = 800
    height = 600
    title = "Smart Home Simulation"

    scene = new Scene {
      content = ???
    }

    onCloseRequest = handle {
      Platform.exit()
    }
  }
}