package ex10

import rescala._


trait Building {

  trait TLocation

  type Location <: TLocation

  trait TRoom extends TLocation

  type Room <: TRoom with Location

  trait CompositeLocation[L <: Location] extends TLocation {
    def locations: Seq[L]
  }

  trait THouse extends CompositeLocation[Room]

  type House <: THouse with Location

  def buildHouse(clock: Clock): House
}