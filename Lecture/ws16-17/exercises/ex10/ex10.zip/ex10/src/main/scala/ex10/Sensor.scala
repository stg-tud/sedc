package ex10

import rescala._

trait Sensor[T] {
  val value: Signal[T]
}