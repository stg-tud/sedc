package ex10

trait Actuator {}
