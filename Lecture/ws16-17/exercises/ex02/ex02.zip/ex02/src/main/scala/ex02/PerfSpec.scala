package ex02

import java.util.Date
import scala.collection.JavaConversions._

trait PerfSpec extends App {

  def measure(name: String)(f: => Unit) = {
    // TODO: Implement here
    ???
  }
}

trait TimeEvaluation /* ??? */ {
   // TODO: Implement here
}

trait MemoryEvaluation /* ??? */ {
  // TODO: Implement here
}

trait Serializer {
  def serialize(name: String, value: Long, unit: String) = {}

  def deserialize(name: String): List[(Date, Long, String)]
}

trait FileSerializer /* ??? */ {

  def fileForName(name: String): java.nio.file.Path = ???

  // TODO: Implement here
}

trait JSONSerializer /* ??? */ {

  def file: java.nio.file.Path = ???

  // TODO: Implement here
}

trait InMemorySerializer /* ??? */ {

  // TODO: Implement here
}

trait PastComparison /* ??? */ {

  class TestFailedException(msg: String) extends Exception(msg)

  def lastExecutionWorse(name: String): Boolean = {
    ???
  }

  // TODO: Implement here
}

// Please describe shortly whether the order you combine TimeEvaluation and MemoryEvaluation matters when combining them for a test.
// If it does, state which order you think is better. If it doesn't, explain why.
// TOOD: Answer here
