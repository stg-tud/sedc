package ex02

object FunctionSets {
  /**
    * This type alias defines how sets are represented.
    */
  type Set = Int => Boolean

  /**
    * This function tests whether a set contains a given element.
    */
  def contains(s: Set, elem: Int): Boolean = s(elem)

  def Set(elem: Int): Set = ???

  /**
   * Returns the union of the two given sets s and t
   */
  def union(s: Set, t: Set): Set = ???

  /**
   * Returns the intersection of the two given sets s and t
   */
  def intersect(s: Set, t: Set): Set = ???

  /**
   * Returns the difference of the two given sets s and t
   */
  def diff(s: Set, t: Set): Set = ???

  /**
   * Returns the subset of s for which p holds
   */
  def filter(s: Set, p: Int => Boolean): Set =
    ???

  /**
   * Returns a set transformed by applying f to each element of s
   */
  def map(s: Set, f: Int => Int): Set =
    ???

  /**
   * Helper function
   * Returns true if all bounded integers within s satisfy p
   */
  def forall(s: Set, p: Int => Boolean): Boolean = {
    ???
  }

  /**
   * Helper function
   * Returns true if a bounded integer exists within s that satisfies p
   */
  def exists(s: Set, p: Int => Boolean): Boolean =
    ???

  /**
    * This function displays the contents of a set in a string.
    */
  def setToString(s: Set): String = {
    ???
  }

  /**
    * This function prints the contents of a set on the console.
    */
  def printSet(s: Set) {
    println(setToString(s))
  }

  def main(args: Array[String]) {
    println("FunctionSets implementation:")

    // add main implementation here, can be run with sbt run
  }
}
