package ex02

import java.util.Date

import org.scalatest.{FlatSpec, Matchers}


class TimeEvaluationTest extends FlatSpec with Matchers {

  var lastValue: Long = -1;

  trait SerializationMock extends Serializer {

    override def serialize(name: String, value: Long, unit: String): Unit = {
      lastValue = value
    }

    def deserialize(name: String): List[(Date, Long, String)] = throw new UnsupportedOperationException("Not used");
  }

  class MyTimeEvaluationTest extends TimeEvaluation with SerializationMock {}

  "TimeEvaluationTest elapsed time" should "be >= 0" in {
    {
      new MyTimeEvaluationTest().measure("42") {
        println("almost nothing")
      }
    }

    assert(lastValue >= 0)
  }
}
