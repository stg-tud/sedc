package ex02

import java.nio.file.Files

import org.scalatest.{FlatSpec, Matchers}


class JSONSerializerTest extends FlatSpec with Matchers {

  class MyTestJSONSerializer extends JSONSerializer {}

  val fs = new MyTestJSONSerializer


  "deserialize after serialize" should "contain serialized entry" in {
    val f = fs.file
    if (Files.exists(f))
      Files.delete(f)

    fs.serialize("test1", 42, "truth")
    fs.deserialize("test1").last._2 should equal (42)
  }

  "desiralize for one name" should "not affect others" in {
    val f = fs.file
    if (Files.exists(f))
      Files.delete(f)

    fs.serialize("test1", 42, "truth")
    fs.deserialize("test2").isEmpty should be (true)
    fs.deserialize("test1").last._2 should equal (42)
  }

}
