package ex02

import java.util.Date

import org.scalatest.{FlatSpec, Matchers}

class MemoryAndTimeTest extends FlatSpec with Matchers {

  var seen: Set[String] = Set()

  trait MockTestSerializer extends Serializer {
    override def serialize(name: String, value: Long, unit: String): Unit = {
      seen += unit
    }

    override def deserialize(name: String): List[(Date, Long, String)] = throw new UnsupportedOperationException()
  }

  class MyMemoryAndTimeEvaluation extends MemoryEvaluation with TimeEvaluation with MockTestSerializer

  "using both memory and time evaluation" should "yield an entry of both units" in {
    new MyMemoryAndTimeEvaluation().measure("test") {

    }
    seen.contains("ns") should be (true)
    seen.contains("b") should be (true)
  }

}
