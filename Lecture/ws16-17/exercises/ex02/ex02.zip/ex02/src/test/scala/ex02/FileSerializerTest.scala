package ex02

import java.nio.file.Files

import org.scalatest.{FlatSpec, Matchers}


class FileSerializerTest extends FlatSpec with Matchers {

  class MyTestFileSerializer extends FileSerializer { }

  val fs = new MyTestFileSerializer

  "deserialize after serialize" should "contain serialized entry" in {
    val f = fs.fileForName("test1")
    if (Files.exists(f))
      Files.delete(f)

    fs.serialize("test1", 42, "truth")
    fs.deserialize("test1").last._2 should equal (42)
  }

  "desiralize for one name" should "not affect others" in {
    val f = fs.fileForName("test1")
    if (Files.exists(f))
      Files.delete(f)

    val f2 = fs.fileForName("test2")
    if (Files.exists(f2))
      Files.delete(f2)

    fs.serialize("test1", 42, "truth")
    fs.deserialize("test2").isEmpty should be (true)
  }
}
