package ex02

import java.util.Date

import org.scalatest.{FlatSpec, Matchers}

import scala.util.Random


class PastComparisonTest extends FlatSpec with Matchers {

  trait SerializationMock extends Serializer {

    override def serialize(name: String, value: Long, unit: String): Unit = {
    }

    def deserialize(name: String): List[(Date, Long, String)] = {
      List((new Date(), 10l, "ns"), (new Date(), 20l, "ns"), (new Date(), 10l, "b"), (new Date(), 10l, "b"))
    }
  }

  trait SerializationMock2 extends Serializer {

    override def serialize(name: String, value: Long, unit: String): Unit = {
    }

    def deserialize(name: String): List[(Date, Long, String)] = {
      List((new Date(), 20l, "ns"), (new Date(), 20l, "ns"), (new Date(), 10l, "b"), (new Date(), 20l, "b"))
    }
  }

  trait SerializationMock3 extends Serializer {

    override def serialize(name: String, value: Long, unit: String): Unit = {
    }

    def deserialize(name: String): List[(Date, Long, String)] = {
      List((new Date(), 20l, "ns"), (new Date(), 10l, "ns"))
    }
  }

  class MyPastComparisonTest extends TimeEvaluation with PastComparison with SerializationMock {
    override def comparisonThreshold: Double = 0.05
  }

  class MyPastComparisonTest2 extends TimeEvaluation with PastComparison with SerializationMock2 {
    override def comparisonThreshold: Double = 0.05
  }

  class MyPastComparisonTest3 extends TimeEvaluation with PastComparison with SerializationMock3 {
    override def comparisonThreshold: Double = 0.05
  }

  "PastComparison" should "detect too slow second execution" in {
    new MyPastComparisonTest().lastExecutionWorse("42") should be(true)
  }

  "PastComparison" should "detect too slow second execution in both units" in {
    new MyPastComparisonTest2().lastExecutionWorse("42") should be(true)
  }

  "PastComparison" should "detect too fast second execution" in {
    new MyPastComparisonTest3().lastExecutionWorse("42") should be(true)
  }

  "This test" should "throw an exception" in {
    assertThrows[Exception] {
      new MyPastComparisonTest().measure("42") {

      }
    }
  }
}
