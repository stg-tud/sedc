package ex07

object PizzaTest extends App {
  val fp = FamilyPizza(SalamiPizza + Cheese + Cheese + Salami + Ham)
  println(fp)
}