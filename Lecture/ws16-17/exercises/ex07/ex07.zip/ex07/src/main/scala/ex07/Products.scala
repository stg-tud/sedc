package ex07

import Price._

/**
 * The base trait for all items that can be ordered in the store.
 */
trait Product {
  def name: String
  def price: Price
}

trait Pizza // extends ...

// TODO: implement hierarchy
