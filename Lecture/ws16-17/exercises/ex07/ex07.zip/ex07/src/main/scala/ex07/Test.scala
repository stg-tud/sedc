package ex07

object PizzaTest extends App {
  // TODO: implement 3 test cases
}
