package ex07
/*
 * We model prices with a small DSL
 */
object Price {
  implicit def int2Price(n: Int): PriceOps = new PriceOps(n)
}

class PriceOps(val n: Int) extends AnyVal {
  def eur(cents: Int) = {
    if (cents > 100) throw new IllegalArgumentException("Cents must be in 0..99 range.")
    new Price(n * 100 + cents)
  }
}

class Price(val cents: Int) extends AnyVal {
  def +(that: Price): Price = new Price(cents + that.cents)

  override def toString() = "EUR " + cents/100 + "." + cents%100
}
