package ex01

import org.slf4j.LoggerFactory

trait Logger {
  val log = LoggerFactory.getLogger(this.getClass.getName)

  def debug(msg: => String) = {
    if (log.isDebugEnabled)
      log.debug(msg)
  }

  def info(msg: => String) = {
    if (log.isInfoEnabled())
      log.info(s"$msg")
  }

  def warn(msg: => String) = {
    if (log.isWarnEnabled())
      log.warn(s"$msg")
  }

  def error(msg: => String) = {
    if (log.isErrorEnabled())
      log.error(s"$msg")
  }
}

object Logging extends Logger {

  def main(args: Array[String]) = {
    debug("Debug")
    info("Info")
    warn("Warn")
    error("Error")
  }
}

