package ex01

import scala.language.postfixOps


object TreeSets {

  abstract class IntSet {
    def incl(x: Int): IntSet

    def contains(x: Int): Boolean

    def foreach(f: Int => Unit)

    def filter(p: Int => Boolean): IntSet = {
      var res: IntSet = Empty
      foreach { x => if (p(x)) res = res.incl(x) }
      res

      //filter0(p, Empty)
    }


    def filter0(p: Int => Boolean, accu: IntSet): IntSet

    def intersect(that: IntSet): IntSet = filter(that contains _)

    override def toString = {
      var res = ""
      foreach { s => res += s + " " }
      res
    }
  }

  case object Empty extends IntSet {
    def contains(x: Int): Boolean = false

    def incl(x: Int): IntSet = NonEmpty(x, Empty, Empty)

    def foreach(f: Int => Unit) {}

    def filter0(f: Int => Boolean, accu: IntSet): IntSet = accu
  }


  case class NonEmpty(elem: Int, left: IntSet, right: IntSet) extends IntSet {
    def contains(x: Int): Boolean =
      if (x < elem) left.contains(x)
      else if (x > elem) right.contains(x)
      else true

    def incl(x: Int): IntSet =
      if (x < elem) NonEmpty(elem, left.incl(x), right)
      else if (x > elem) NonEmpty(elem, left, right.incl(x))
      else this

    def foreach(f: Int => Unit) {
      left foreach f
      f(elem)
      right foreach f
    }

    def filter0(f: Int => Boolean, accu: IntSet): IntSet =
      right.filter0(f, left.filter0(f, if (f(elem)) accu.incl(elem) else accu))
  }

  // incl and contains as functions:
  def incl(s: IntSet, x: Int): IntSet = s match {
    case NonEmpty(elem, left, right) =>
      if (x < elem) NonEmpty(elem, incl(left, x), right)
      else if (x > elem) NonEmpty(elem, left, incl(right, x))
      else s
    case Empty =>
      NonEmpty(x, Empty, Empty)
  }

  def contains(s: IntSet, x: Int): Boolean = s match {
    case NonEmpty(elem, left, right) =>
      if (x < elem) contains(left, x)
      else if (x > elem) contains(right, x)
      else true
    case Empty =>
      false
  }

  def main(args: Array[String]) {
    println("TreeSets implementation:")
    val s = Empty.incl(3).incl(1).incl(4)
    val t = Empty.incl(2).incl(4)
    println(s.contains(1))
    println(s.contains(5))
    println("s = " + s)
    println("t = " + t)
    println("s ^ t = " + s.intersect(t))
  }
}
