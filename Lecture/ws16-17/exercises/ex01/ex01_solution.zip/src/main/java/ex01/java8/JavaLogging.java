package ex01.java8;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.function.Supplier;

interface ILogger {

    Logger log = LoggerFactory.getLogger(ILogger.class);

    default void debug(Supplier<String> msg) {
        if (log.isDebugEnabled()) {
            log.debug(msg.get());
        }
    }

    default void info(Supplier<String> msg) {
        if (log.isInfoEnabled()) {
            log.info(msg.get());
        }
    }

    default void warn(Supplier<String> msg) {
        if (log.isWarnEnabled()) {
            log.warn(msg.get());
        }
    }

    default void error(Supplier<String> msg) {
        if (log.isErrorEnabled()) {
            log.error(msg.get());
        }
    }
}

public class JavaLogging implements ILogger {

    public JavaLogging() {
        debug(() -> "Debug");
        info(() -> "Info");
        warn(() -> "Warn");
        error(() -> "Error");
    }

    public static void main(String[] args) {
        new JavaLogging();
    }
}
