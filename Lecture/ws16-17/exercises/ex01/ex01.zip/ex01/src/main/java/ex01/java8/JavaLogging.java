package ex01.java8;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

interface ILogger {

}

//TODO: Implement ILogger interface and use the methods provided by the interface
public class JavaLogging {

    // TODO: Move logging to the ILogger interface and provide methods for the different log levels using Java 8 default methods
    private static Logger log = LoggerFactory.getLogger(JavaLogging.class);

    public static void main(String[] args) {
        if (log.isDebugEnabled()) {
            log.debug("Java logging debug statement");
        }
    }
}
