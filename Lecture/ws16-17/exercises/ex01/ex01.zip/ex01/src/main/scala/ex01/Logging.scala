package ex01

import org.slf4j.LoggerFactory

trait Logger {

}

// TODO: Extend Logger trait and use the methods provided by the trait
object Logging {

  // TODO: Move logging to the Logger trait and provide methods for the different log levels
  val log = LoggerFactory.getLogger(this.getClass.getName)

  def main(args: Array[String]) = {
    if (log.isDebugEnabled)
      log.debug("Scala logging debug statement")
  }
}

