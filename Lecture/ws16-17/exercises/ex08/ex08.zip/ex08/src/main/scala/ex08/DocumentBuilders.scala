package ex08
import java.net.URL
import scala.collection.mutable.ArrayBuffer

trait DocumentBuilder[Result] {
  def headline(level: Int, title: String)
  def linebreak()
  def link(url: URL, text: String)
  def text(str: String)
  //def canvas(width: Int, height: Int)(draw: Canvas => Unit)
  // def image(image: Image)

  def result: Result
}


class SimpleDocumentBuilder(val html: HTMLBuilder) extends DocumentBuilder[String] // TODO: implement

class PaginatedDocumentBuilder(val newHTML: ()=>HTMLBuilder) extends DocumentBuilder[Seq[String]] // TODO: implement
