package ex08

import java.net.URL
import javax.imageio.ImageIO
import java.io.IOException
import java.awt.image.BufferedImage
import java.io.File
import java.io.ByteArrayOutputStream
import java.awt.GraphicsEnvironment

object Image {
  private[ex09] def encodeBase64(array: Array[Byte]): String = {
    val encoder = new sun.misc.BASE64Encoder
    encoder.encode(array)
  }

  def config = GraphicsEnvironment.getLocalGraphicsEnvironment
    .getDefaultScreenDevice.getDefaultConfiguration

  def resizeImage(image: BufferedImage, width: Int, height: Int): BufferedImage = {
    val res = Image.config.createCompatibleImage(width, height)
    val gfx = res.createGraphics()
    gfx.drawImage(image, 0, 0, width, height, null)
    gfx.dispose()
    res
  }
}

/**
 * Represents an image with a width and height. Image data can be exported
 * to a PNG byte array.
 */
trait Image {
  /**
   * The width of this image
   */
  def width: Int

  /**
   * The height of this image
   */
  def height: Int

  /**
   * Creates a byte array that contains this image in the PNG format. May throw an
   * exception if the image data cannot be accessed.
   */
  def toPNG: Array[Byte]
}

/**
 * Image adapter to AWT buffered images, which are stored in memory.
 */
class LocalImage(image: BufferedImage) // TODO: implement

/**
 * Proxy to an image at the given URL. Loads image data only when needed.
 */
class RemoteImage(val url: URL, val width: Int, val height: Int) // TODO: implement
