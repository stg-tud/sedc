package ex08

import java.awt.Desktop
import java.io.File
import java.io.PrintWriter
import java.net.URI
import java.net.URL

object Tests {
  /**
   * Saves the given HTML code to a temporary file and opens it in the default web browser.
   *
   * If this doesn't work on your system, you may have to open the temp file manually.
   * The URI of the temp file is printed to the console and can be copied to the address bar
   * of your browser.
   *
   * If your browser won't display your HTML correctly, it is either because your HTML is not
   * correct, or your browser cannot handle your code (does not support HTML 5 canvas or Base64
   * encoding). Generally make sure you have a recent browser installed. We have tested our
   * HTML with recent versions of Chrome, Firefox and Safari. All support HTML 5 Canvas and
   * Base64 encoding.
   *
   * In order to debug your HTML, you can use a debugger, e.g., in Chrome under menu item
   * View -> Developer -> Developer Tools. In tab "Console", it will show an error message if
   * it could not parse your HTML.
   */
  def openBrowser(html: String) {
    val tempFile = File.createTempFile("MyEx10Test", ".html")
    val uri = tempFile.toURI
    println("Creating temporary file at " + uri)
    val out = new PrintWriter(tempFile)
    out.append(html)
    out.close()
    Desktop.getDesktop.browse(uri)
  }

  def buildTestHTML[R](b: DocumentBuilder[R]): DocumentBuilder[R] = {
    b.headline(1, "Hello, World!")
    b.text("I hate HTML...")
    b.linebreak
    b.canvas(300, 200) { c =>
      c.setColor(Color.Red.withAlpha(128))
      c.fillRectangle(10, 10, 50, 50)
      c.setColor(Color.Blue.withAlpha(128))
      c.fillRectangle(30, 30, 50, 50)
    }
    b.linebreak
    b.headline(1, "HTML is awesome!")
    b.linebreak
    b.image(Image(new URL("http://imgs.xkcd.com/comics/tags.png"), 450, 60))
    b.linebreak
    b.link(new URL("http://en.wikipedia.org/wiki/Christopher_Alexander#Computer_science"), "But I do like design patterns!")
    b.linebreak
    b.link(new URL("http://xkcd.com/747/"), "Nerd!")
    b
  }

  def openDoc(b: DocumentBuilder[String]) {
    val res = b.result
    println(res)
    openBrowser(res)
  }

  def openAllDocs(b: DocumentBuilder[Seq[String]]) {
    val res = b.result
    println(res)
    res foreach { openBrowser(_) }
  }
}

import Tests._


/**
 * Opens a couple of generated test pages in your default browser.
 */
object HTMLTests extends App {
  val b1 = buildTestHTML(new SimpleDocumentBuilder(new HTML5Builder))
  openDoc(b1)

  val b2 = buildTestHTML(new PaginatedDocumentBuilder(() => new HTML5Builder))
  openAllDocs(b2)

  val b3 = buildTestHTML(new SimpleDocumentBuilder(new HTML4StrictBuilder))
  openDoc(b3)
}
