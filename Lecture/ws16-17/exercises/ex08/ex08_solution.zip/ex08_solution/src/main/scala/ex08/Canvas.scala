package ex08

import java.awt.GraphicsEnvironment
import java.util.Base64
import java.io.ByteArrayOutputStream
import javax.imageio.ImageIO

object Color {
  val Black = Color(0, 0, 0)
  val White = Color(255, 255, 255)
  val Red = Color(255, 0, 0)
  val Blue = Color(0, 0, 255)
  val Green = Color(0, 255, 0)

  def comp2Double(c: Int): Double = c / 255d
}

case class Color(r: Int, g: Int, b: Int, a: Int = 255) {
  def withAlpha(newAlpha: Int): Color = new Color(r, g, b, newAlpha)
}

trait Canvas {
  def width: Int
  def height: Int

  def setColor(c: Color)
  def drawLine(x0: Double, y0: Double, x1: Double, y1: Double)
  def fillRectangle(x: Double, y: Double, w: Double, h: Double)

  def close()
}

object CanvasSurface {
  private var i = 0
  def uniqueId(prefix: String): String = {
    i += 1
    if (!prefix(0).isLetter) throw new IllegalArgumentException("Prefix must start with a letter")
    prefix + i
  }
}

/**
 * A surface that exports HTML 5 canvas code.
 */
class HTML5Canvas(val width: Int, val height: Int, code: SourceCodeBuilder) extends Canvas {
  private val id = CanvasSurface.uniqueId("canvas")
  
  // you had to implement:
  
  code += "<canvas id=\"" += id += "\" width=\"" += width += "\" height=\"" += height += "\"></canvas>\n"
  code += "<script type=\"text/javascript\">\n"
  code.indent
  code += "function draw_" += id += "() {\n"
  code.indent
  code += "var canvas = document.getElementById('" += id += "');\n"
  code += "if (canvas.getContext) {\n"
  code.indent
  code += "var c = canvas.getContext('2d');\n"

  def setColor(c: Color) {
    code += "c.fillStyle = 'rgba(" += c.r += "," += c.g += "," += c.b += "," += Color.comp2Double(c.a) += ")';\n"
    code += "c.strokeStyle = 'rgba(" += c.r += "," += c.g += "," += c.b += "," += Color.comp2Double(c.a) += ")';\n"
  }

  def drawLine(x0: Double, y0: Double, x1: Double, y1: Double) {
    code += "c.beginPath();\n"
    code += "c.moveTo(" += x0.toInt += "," += y0.toInt += ");\n"
    code += "c.lineTo(" += x1.toInt += "," += y1.toInt += ");\n"
    code += "c.stroke();\n"
  }
  def fillRectangle(x: Double, y: Double, w: Double, h: Double) {
    code += "c.fillRect(" += x.toInt += "," += y.toInt += "," += w.toInt += "," += h.toInt += ");\n"
  }

  def close() {
    code.unindent
    code += "};"

    code.unindent
    code += "};\n"
    code += "draw_" += id += "();"
    code.unindent
    code += "</script>"
  }
  
  // end of HTML5Canvas implementation.
}

/**
 * A surface that exports a PNG image.
 */
class PNGCanvas(val width: Int, val height: Int, html: HTMLBuilder) extends Canvas {
  private val image = Image.config.createCompatibleImage(width, height)
  private val gfx = image.createGraphics
  gfx.setBackground(java.awt.Color.white)
  gfx.clearRect(0, 0, width, height)

  def setColor(c: Color) {
    gfx.setColor(new java.awt.Color(c.r, c.g, c.b, c.a))
  }
  def drawLine(x0: Double, y0: Double, x1: Double, y1: Double) {
    gfx.drawLine(x0.toInt, y0.toInt, x1.toInt, y1.toInt)
  }
  def fillRectangle(x: Double, y: Double, w: Double, h: Double) {
    gfx.fillRect(x.toInt, y.toInt, w.toInt, h.toInt)
  }

  def close() {
    // NOTE: this uses a class that is not part of the Java standard library and 
    // likely only present on Sun/Oracle JVMs. 
    val encoder = Base64.getEncoder
    val out = new ByteArrayOutputStream
    ImageIO.write(image, "png", out)
    val result = encoder.encodeToString(out.toByteArray)
    out.close()
    html.image(new LocalImage(image))
  }
}