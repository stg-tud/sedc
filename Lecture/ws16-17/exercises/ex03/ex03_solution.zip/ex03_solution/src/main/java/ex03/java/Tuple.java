package ex03.java;

import java.util.Arrays;
import java.util.function.Function;

import sun.print.resources.serviceui;

abstract class Tuple<A> {
	public static <X, Y extends X, Z extends X> Tuple<X> add(Tuple<Y> t, Z c) {
		X[] as = Arrays.copyOf(t.toArray(), t.length() + 1);
		as[t.length()] = c;
		return new TupleN<X>(as);
	}

	public abstract int length();

	public abstract A get(int i);

	public abstract <B> Tuple<B> map(Function<A, B> f);

	public abstract boolean contains(Object a);

	public abstract A[] toArray();

	// this probably exists somewhere in the JDK, but couldn't find it
	protected A[] toArray(A... a) {
		return a;
	}
}

class Tuple0<A> extends Tuple<A> {

	public int length() {
		return 0;
	}

	public A get(int i) {
		throw new IllegalArgumentException("Index out of bounds: " + i);
	}

	public boolean contains(Object a) {
		return false;
	}

	@Override
	public A[] toArray() {
		return null;
	}

	@Override
	public <B> Tuple<B> map(Function<A, B> a) {
		return new Tuple0<B>();
	}

}

// this can extend Tuple0 in Java, since it's not an object here
class Singleton<A> extends Tuple<A> {
	protected final A x;

	public Singleton(A x) {
		this.x = x;
	}

	public int length() {
		return 1;
	}

	public A get(int i) {
		if (i == 0)
			return x;
		else
			throw new IllegalArgumentException("Index out of bounds: " + i);
	}

	public boolean contains(Object a) {
		return this.x == a;
	}

	// in a proper API, the array should probably be copied, but we don't care
	// here.
	public A[] toArray() {
		return toArray(x);
	}

	@Override
	public <B> Tuple<B> map(Function<A, B> f) {
		return new Singleton<B>(f.apply(x));
	}
}

class Pair<A> extends Tuple<A> {
	protected final A x, y;

	public Pair(A x, A y) {
		this.x = x;
		this.y = y;
	}

	public int length() {
		return 2;
	}

	public A get(int i) {
		switch (i) {
			case 0:
				return x;
			case 1:
				return y;
			default:
				throw new IllegalArgumentException("Index out of bounds: " + i);
		}
	}

	public boolean contains(Object a) {
		return x == a || y == a;
	}

	// in a proper API, the array should probably be copied, but we don't care
	// here.
	public A[] toArray() {
		return toArray(x, y);
	}

	@Override
	public <B> Tuple<B> map(Function<A, B> f) {
		return new Pair<B>(f.apply(x), f.apply(y));
	}
}

class TupleN<A> extends Tuple<A> {
	private final A[] as;

	public TupleN(TupleN<A> t, A a) {
		this.as = Arrays.copyOf(t.as, t.length() + 1);
		this.as[t.length()] = a;
	}

	public TupleN(A... as) {
		this.as = as;
	}

	public int length() {
		return as.length;
	}

	public A get(int i) {
		return as[i];
	}

	public boolean contains(Object a) {
		return Arrays.asList(as).contains(a);
	}

	// in a proper API, the array should probably be copied, but we don't care
	// here.
	public A[] toArray() {
		return as;
	}

	@Override
	public <B> Tuple<B> map(Function<A, B> f) {
		if (as.length == 0) {
			return new TupleN<B>();
		}
		A[] as2 = Arrays.copyOf(as, as.length - 1);
		return new TupleN<B>((TupleN<B>)new TupleN<A>(as2).map(f),
				f.apply(as[as.length - 1]));
	}
}
