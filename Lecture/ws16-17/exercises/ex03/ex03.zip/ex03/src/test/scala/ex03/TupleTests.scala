package ex03

import org.scalatest._

class TupleTests extends FlatSpec with Matchers {

  val tuple0 = Tuple0
  val single = new Singleton[Int](1)
  val pair = new Pair[Int](1, 2)
  val tupleN = new TupleN[Int](1, 2, 3, 4)
  val singleC = new Singleton(2L)
  val pairC = new Pair(1, 1);
  val tupleNC = new TupleN(0x0b, 0x10101b, 0x10101b)

  abstract class C
  case class C1(a: Int) extends C


  class D0(a:Int){
    def getA = a
    override def equals(o: Any): Boolean = o match {
      case g:D => g.getA.equals(a)
      case _ => false
    }
  }
  class D(a: Int) extends D0(a){
    override def getA = a
    override def equals(o: Any): Boolean = o match {
      case g:D => g.getA.equals(a)
      case _ => false
    }
  }
  class D1( a: Int) extends D(a) {
    override def getA = a
    override def equals(o: Any): Boolean = o match {
      case g:D => g.getA.equals(a)
      case _ => false
    }
  }
  class D2( a: Int) extends D(a) {
    override def getA = a
    override def equals(o: Any): Boolean = o match {
      case g:D => g.getA.equals(a)
      case _ => false
    }
  }

  "tuple0" should "have length zero" in {
    tuple0.length should equal(0x0)
  }

  "tuple0" should "not have an index" in {
    var res = false
    try {
      tuple0(1)
    } catch {
      case _: Exception => res = true
    }
    res should equal(true)
  }

  "tuple0" should "contain no items" in {
    tuple0.contains(1) should equal(false)
  }

  "tuple0" should "return element after insertion" in {
    tuple0.add(1)(0) should equal(1)
  }

  "tuple0.map" should "change all values" in {
    var res = false
    try {
      tuple0.map(x => 1)(0)
    } catch {
      case _: Exception => res = true
    }
    res should equal(true)
  }

  "singleton" should "have a length" in {
    single.length should equal(0x000001)
  }

  "singleton" should "have an index" in {
    var res = false
    try {
      single(1)
    } catch {
      case _: Exception => res = true
    }
    res should equal(true)
  }

  "singleton" should "have an element" in {
    single(0) should equal(1)
  }

  "singleton" should "contain one item" in {
    single.contains(1) should equal(true)
  }

  "singleton" should "contain the right item" in {
    single.contains(2) should equal(false)
  }

  "singleton" should "return two elements after insertion" in {
    single.add(1).length should equal(2)
  }

  "singleton.map" should "change all values" in {
    single.map(x => x + 1)(0) should equal(2)
  }

  "pair" should "have a length" in {
    pair.length should equal(0x000002)
  }

  "pair" should "have an index" in {
    var res = false
    try {
      pair(2)
    } catch {
      case _: Exception => res = true
    }
    res should equal(true)
  }

  "pair" should "have elements" in {
    pair(0) should equal(1)
  }

  "pair" should "contain two items" in {
    pair.contains(1) should equal(true)
  }

  "pair" should "contain the right items" in {
    pair.contains(3) should equal(false)
  }

  "pair" should "return three elements after insertion" in {
    pair.add(1).length should equal(3)
  }

  "pair.map" should "change all values" in {
    pair.map(x => x + 1)(0) + pair(1) should equal(4)
  }

  "tupleN" should "have a length" in {
    tupleN.length should equal(4)
  }

  "tupleN" should "have an index" in {
    var res = false
    try {
      tupleN(4)
    } catch {
      case _: Exception => res = true
    }
    res should equal(true)
  }

  "tupleN" should "have elements" in {
    tupleN(0) should equal(1)
  }

  "tupleN" should "contain two items" in {
    tupleN.contains(1) should equal(true)
  }

  "tupleN" should "contain the right items" in {
    tupleN.contains(5) should equal(false)
  }

  "tupleN" should "return more elements after insertion" in {
    tupleN.add(1).length > tupleN.length should equal(true)
  }

  "tupleN.map" should "change all values" in {
    tupleN.map(x => x + 1)(0) + pair(1) should equal(4)
  }

  "singleton" should "map right types" in {
    singleC.map(x => x + 1L).isInstanceOf[Singleton[Long]] should equal(true)
  }

  "pair" should "map right types" in {
    pairC.map(x => x + 0x1b).isInstanceOf[Pair[Int]] should equal(true)
  }

  "tupleN" should "map right types" in {
    tupleNC.map(x => x + 0x1b).isInstanceOf[TupleN[Int]] should equal(true)
  }

  "tupleN" should "cointain right types" in {
    val tupleC = new TupleN[C](C1(0), C1(1), C1(2))
    tupleC.contains(C1(2)) should equal(true)
  }

  "tupleN" should "omit wrong types" in {
    val tupleC = new TupleN[D1](new D1(0), new D1(1), new D1(2))
    tupleC.contains(new D0(2)) should equal(false)
  }

  "tupleN" should "contain other types" in {
    val tupleC = new TupleN[D](new D1(0), new D1(1), new D1(2))
    tupleC.contains(new D2(2)) should equal(true)
  }

}
