package sc.design_principle
package single_responsibility

class Shutter { def raise() { /*...*/ }; def lower() { /*...*/ }; }
