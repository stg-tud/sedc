package sc.design_principle
package single_responsibility

class Light { def turnOn() { /*...*/ }; def turnOff() { /*...*/ }; }
