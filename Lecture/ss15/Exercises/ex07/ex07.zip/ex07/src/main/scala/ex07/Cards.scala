package ex07

trait Cards {
  val deck: Seq[Card]
  type Card <: TCard

  trait TCard {
    def name: String
  }

  val cardOrdering: Ordering[Card]
}