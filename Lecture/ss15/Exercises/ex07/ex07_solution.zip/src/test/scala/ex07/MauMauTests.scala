package ex07

import org.scalatest._

class MauMauTests extends FlatSpec with Matchers {
  
  "the AlwaysFirstPlayer" should "possibly cheat" in {
    val maumau = new MauMau
    val p = new maumau.AlwaysFirstCardPlayer
    maumau.players = List(p)
    maumau.playedStack = List(maumau.deck(0))
    // we force the player to only draw cards that forces the player to cheat, as no card will match
    maumau.drawingStack = maumau.deck.filter { c => c.rank != maumau.deck(0).rank && c.suit != maumau.deck(0).suit }.toList

    maumau.dealCard(p)
    maumau.dealCard(p)

    // player has two cards now and tries to play the first one...
    p.play() should equal(Some(p.cards.head))

    maumau.playersTurn(p)
    
    // player cheated, so he should have 3 cards now
    p.cards.size should be >= (3)
  }

  "the NoCheater" should "never cheat" in {
    val maumau = new MauMau
    val p = new maumau.NoCheater
    maumau.players = List(p)

    for { i <- 1 until 5 } {
      maumau.dealCard(p)
      // now the player has at least one card
      val noCheats = p.play() match {
        // the player picked a card, so it has to be valid
        case Some(c) => maumau.validPlay(c)
        // the player did not pick any card, so all his cards have to be invalid
        case None => p.cards.forall { c => !maumau.validPlay(c) }
      }
      noCheats should equal (true)
    }
  }
  
  "played card" should "be on top" in {
    val maumau = new MauMau
    val p = new maumau.NoCheater
    maumau.players = List(p)
    
    // prep the drawing stack to only contain playable cards...
    maumau.drawingStack = maumau.drawingStack.filter { c => c.rank == maumau.top.rank || c.suit == maumau.top.suit }
    
    //give the player a card
    maumau.dealCard(p)
    
    // card to be played, has to be some card, as we deal only playable cards...
    val cardToPlay = p.play().get
    
    // the player will have played cardToPlay
    maumau.playersTurn(p)
    
    maumau.top should equal (cardToPlay) 
  }
  
  
}