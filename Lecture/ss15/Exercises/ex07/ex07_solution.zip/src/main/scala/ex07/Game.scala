package ex07

import scala.collection.mutable.Stack
import scala.collection.mutable.Buffer
import scala.util.Random
import scala.collection.mutable.ArrayBuffer
import scala.collection.mutable.Queue
import scala.collection.mutable.LinkedHashMap

trait Game extends Cards {
  
  trait Player {
    var cards: Seq[Card] = Seq()
    
    def play(): Option[Card]
    
    def drawCard(c: Card) {
      cards = c +: cards
    }
  }
  
}

class MauMau extends FullFrenchSuitedCards with Game {
  var players: List[Player] = List()
  
  def currentPlayer = players.head
  
  def nextPlayer = {
    players = (players.tail :+ players.head)
    players.head
  }
  
  def validPlay(play: Card): Boolean =
    suitOrdering.equiv(top.suit, play.suit) || rankOrdering.equiv(top.rank, play.rank)
  
  val rankOrdering: Ordering[Rank] = new Ordering[Rank] {
    val ord = Seq(Two, Three, Four, Five, Six, Seven, Eight, Nine, Ten, Jack, Queen, King, Ace)
    def compare(x: Rank, y: Rank): Int = {
      ord.indexOf(x) - ord.indexOf(y)
    }
  }
  val suitOrdering: Ordering[Suit] = new Ordering[Suit] {
    val ord = Seq(Clubs, Spades, Hearts, Diamonds)
    def compare(x: Suit, y: Suit): Int = {
      ord.indexOf(x) - ord.indexOf(y)
    }
  }
  
  class AlwaysFirstCardPlayer extends Player {
    def play(): Option[Card] = {
      Some(cards.head)
    }
  }
  
  class NoCheater extends Player {
    def play(): Option[Card] = {
      val possibleCards = cards.filter { c => validPlay(c) }
      if (possibleCards.isEmpty) None else Some(possibleCards.head)
    }
  }
  
  var drawingStack: List[Card] = Random.shuffle(this.deck.toList)
  var playedStack: List[Card] = drawCard :: List()
  
  def drawCard: Card = {
    val card = drawingStack.head
    drawingStack = drawingStack.drop(1)
    card
  }
  
  def dealCard(p: Player) {
    p.drawCard(drawCard)
  }
  
  def playCard(c: Card) = {
    playedStack = c +: playedStack
    checkSpecials(c, nextPlayer)
  }
  
  def checkSpecials(c: Card, next: Player) {
    if (c.rank == Eight) {
      next.drawCard(drawCard); next.drawCard(drawCard)
    }
    if (c.rank == King) {
      players = players.reverse
    }
  }
  
  def top = playedStack.head
  
  def playersTurn(p: Player) {
    val playedCard = p.play()
    if (playedCard.isEmpty || !validPlay(playedCard.get)) {
      dealCard(p)
    } else {
      playCard(playedCard.get)
    }
  }
}

object Test extends App{
  val m1 = new MauMau
  println(m1.top)
  val m2 = new MauMau
  
  var x = m1.deck(0)
  // this assignment below should be rejected by the type checker, as you should not be able to mix cards from different decks.
  //x = m2.deck(0)
}