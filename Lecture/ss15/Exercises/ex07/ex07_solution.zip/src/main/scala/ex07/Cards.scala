package ex07

trait Cards {
  val deck: Seq[Card]
  type Card <: TCard

  trait TCard {
    def name: String
    override def toString = name
  }
  
  val cardOrdering: Ordering[Card]
}

trait SuitedCards extends Cards {
  type Suit <: TSuit
  type Card <: TCard

  // this can either extend Ordered or use Ordering as below
  trait TSuit {
    def name: String
  }

  trait TCard extends super.TCard {
    def suit: Suit
  }

  val suits: Seq[Suit]

  val suitOrdering: Ordering[Suit]
}

trait FrenchSuitedCards extends SuitedCards {
  val suits: Seq[Suit] = Seq(Clubs, Diamonds, Hearts, Spades)

  sealed abstract class Suit(val name: String) extends TSuit 
  object Clubs extends Suit("C")
  object Diamonds extends Suit("D")
  object Hearts extends Suit("H")
  object Spades extends Suit("S")
}

trait RankedCards extends Cards {
  type Rank <: TRank
  type Card <: TCard

  trait TRank {
    def name: String
  }

  trait TCard extends super.TCard {
    def rank: Rank
  }

  val ranks: Seq[Rank]

  val rankOrdering: Ordering[Rank]
}

trait FullRankedCards extends RankedCards {
  val ranks: Seq[Rank] = Seq(Two, Three, Four, Five, Six, Seven, Eight, Nine, Ten, Jack, Queen, King, Ace)

  sealed abstract class Rank(val name: String) extends TRank

  object Two extends Rank("2")
  object Three extends Rank("3")
  object Four extends Rank("4")
  object Five extends Rank("5")
  object Six extends Rank("6")
  object Seven extends Rank("7")
  object Eight extends Rank("8")
  object Nine extends Rank("9")
  object Ten extends Rank("10")
  object Jack extends Rank("J")
  object Queen extends Rank("Q")
  object King extends Rank("K")
  object Ace extends Rank("A")
}

trait PiquetRankedCards extends RankedCards {
  val ranks: Seq[Rank] = Seq(Seven, Eight, Nine, Ten, Jack, Queen, King, Ace)

  sealed abstract class Rank(val name: String) extends TRank

  object Seven extends Rank("7")
  object Eight extends Rank("8")
  object Nine extends Rank("9")
  object Ten extends Rank("10")
  object Jack extends Rank("J")
  object Queen extends Rank("Q")
  object King extends Rank("K")
  object Ace extends Rank("A")
}

trait SuitedAndRankedCards extends SuitedCards with RankedCards {
  lazy val deck: Seq[Card] = for (s <- suits; r <- ranks) yield Card(s, r)
  
  type Card <: TCard
  
  trait TCard extends super[SuitedCards].TCard with super[RankedCards].TCard 

  protected[this] def Card(suit: Suit, rank: Rank): Card
  
  // this is just a default ordering that is not true for all games.
  // since it is a val, it can be overridden in subclasses (objects cannot, since they are implicitly final)
  val cardOrdering = new Ordering[Card] {
    def compare(x: Card, y: Card): Int = {
      val ro = rankOrdering.compare(x.rank, y.rank)
      if (ro == 0) suitOrdering.compare(x.suit, y.suit)
      else ro
    }
  }
}

trait FullFrenchSuitedCards extends SuitedAndRankedCards with FrenchSuitedCards with FullRankedCards {
  protected[this] def Card(suit: Suit, rank: Rank): Card = new Card(suit, rank)
  
  // Constructor is private in this solution so that clients can't just create new cards
  // We still have to check in the game logic that the payer doesn't steal card from other players, or
  // the pile or stock
  class Card private[FullFrenchSuitedCards] (val suit: Suit, val rank: Rank)
       extends super[SuitedAndRankedCards].TCard
       with super[FrenchSuitedCards].TCard {
    def name: String = rank.name + " of " + suit.name
  }
}

