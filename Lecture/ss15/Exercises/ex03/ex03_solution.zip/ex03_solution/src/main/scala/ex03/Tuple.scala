package ex03


trait Tuple[+A] {
  def length: Int
  def apply(i: Int): A
  def map[B](f: A => B): Tuple[B]
  def contains[B >: A](b: B): Boolean
  def add[B >: A](b: B): Tuple[B]
}

object Tuple0 extends Tuple[Nothing] {
  def length: Int = 0
  def apply(i: Int): Nothing = throw new IllegalArgumentException("Index out of bounds: " + 0)
  def map[B](f: Nothing => B): Tuple[B] = Tuple0
  def contains[B](b: B): Boolean = false

  def add[B](b: B): Singleton[B] = new Singleton(b)
}

class Singleton[+A](x: A) extends Tuple[A] {
  def length: Int = 1
  def apply(i: Int): A = i match {
    case 0 => x
    case _ => throw new IllegalArgumentException("Index out of bounds: " + i)
  }
  def map[B](f: A => B): Singleton[B] = new Singleton(f(x))
  def contains[B >: A](b: B): Boolean = x == b

  def add[B >: A](y: B): Pair[B] = new Pair(x, y)
}

class Pair[+A](x: A, y: A) extends Tuple[A] {
  override def length: Int = 2
  override def apply(i: Int): A = i match {
    case 0 => x
    case 1 => y
    case _ => throw new IllegalArgumentException("Index out of bounds: " + i)
  }
  override def map[B](f: A => B): Pair[B] = new Pair(f(x), f(y))
  override def contains[B >: A](b: B): Boolean = x == b || y == b

  override def add[B >: A](z: B): TupleN[B] = new TupleN(x, y, z)
}

// could also use an Array[A] or Seq[A]
class TupleN[A](s: A*) extends Tuple[A] {
  override def length: Int = s.length
  override def apply(i: Int): A = s(i)
  override def map[B](f: A => B): Tuple[B] = new TupleN((s map f): _*)
  override def contains[B >: A](b: B): Boolean = s contains b

  override def add[B >: A](z: B): TupleN[B] = new TupleN((s :+ z): _*)
}


object UserTestMain {
  def main(args: Array[String]) {
    //dummy pair test
    val p0 = new Pair( 3, 5 )
    for( x <- 1 to 6 ) { println( x+ " in p0: " + p0.contains( x ) ) }
  }
}
