package ex03.java;


abstract class Tuple {

}

