package ex03


trait Tuple {
  
}

