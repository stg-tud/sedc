package ex05

import swing.{ Panel, MainFrame }
import java.awt.{ Color, Graphics2D, Dimension, Point, Font }
import Animation._
import Time._
import makro.SignalMacro.{SignalM => Signal}
import scala.language.postfixOps


object Main extends ReactiveSwingApp {
  val Width = 700
  val Height = 600
  val Size = 20

  def top = new MainFrame {
    title = "Reactive Animations"
    resizable = false
    val panel = new Panel {
      preferredSize = new Dimension(Width, Height)
          
      // Your animation signals go here:
      val lineX = (animate(100 ->> 300) in (2 secs) repeat).start

      val sineX = (animate(100 ->> 400) in (2 secs) bounce).start
      val sineY = (animate(x => 200 + math.sin(x * 10) * 50) in (2 secs) bounce).start

      val circleX = (animate(x => 400 + math.cos(2 * x * math.Pi) * 50) in (10 secs) repeat).start
      val circleY = (animate(x => 400 + math.sin(2 * x * math.Pi) * 50) in (10 secs) repeat).start

      // setup and redraw code
      val stateChanged = Clock.ticks
      stateChanged += { _ => repaint() }
      
      val time = Signal { Clock.time().inSeconds + "s runnung..." }
      
      override def paintComponent(g: Graphics2D) {
        super.paintComponent(g)
        g.setColor(java.awt.Color.DARK_GRAY)
        g.drawString(time(), 10, 20)
        g.fillOval(lineX().toInt, 100, Size, Size)
        g.fillOval(sineX().toInt, sineY().toInt, Size, Size)
        g.fillOval(circleX().toInt, circleY().toInt, Size, Size)
      }
    }
    contents = panel
  }
}