package ex05

import rescala.events.{ Event, ImperativeEvent }
import Time._
import rescala.Signal
import scala.language.postfixOps

/**
 * A utility class providing timer events and signals.
 */
object Clock {
  /**
   * An event that emits time stamps every few milliseconds, starting at 0 at program startup (roughly). 
   * This, or the signal below, can be used for animation.
   */
  val ticks: Event[Time] = new ImperativeEvent[Time] { self =>
    val timer = new javax.swing.Timer(10, new java.awt.event.ActionListener {
      private var t0 = -1L
      def actionPerformed(e: java.awt.event.ActionEvent) {
        // Initialize t0 here, since the first event sometimes takes a while to get through the Swing queue.
        // This simply reduces stutter. 
        if (t0 < 0) t0 = e.getWhen
        val t = e.getWhen - t0
        self.apply(t msecs)
      }
    })
    timer.start()
  }
  
  /**
   * A signal holding the time since program startup. It is updated often enough to be used for animation.
   */
  val time: Signal[Time] = ticks.latest(0L nsecs)

  // not for this exercise
  //def seconds: Signal[Time] = ???
}