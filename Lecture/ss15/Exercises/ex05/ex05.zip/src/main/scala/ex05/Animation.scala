package ex05

import rescala._
import makro.SignalMacro.{SignalM => Signal}
import Time._
import scala.language.implicitConversions

/**
 * Clamping could alternatively be modeled as simple closures Double => Double.
 */
abstract class Policy {
  def clamp(v: Double): Double
}

object Once extends Policy {
  def clamp(v: Double): Double =
    ???
}

object Repeat extends Policy {
  def clamp(v: Double): Double = ???
}

object Bounce extends Policy {
  def clamp(v: Double): Double = ???
}

object Animation {
  def animate(f: Double => Double): Animation = ???
  
  implicit def int2PathOps(x: Int): PathOps = new PathOps(x)

  class PathOps(val x: Int) extends AnyVal {
    def ->>(y: Int): Path = ???
  }
  
  type Path = Double => Double
}

/**
 * An instances of this class represents a one dimensional animation of a Double value.
 */
class Animation(/*your parameters here*/) {
  def in(t: Time): Animation = ???
  def repeat: Animation = ???
  def bounce: Animation = ???

  def start: Signal[Double] = {
    ???
  }
}





