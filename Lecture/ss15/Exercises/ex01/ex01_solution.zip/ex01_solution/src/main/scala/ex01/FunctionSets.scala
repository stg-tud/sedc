package ex01

object FunctionSets {
  /**
   * This type alias defines how sets are represented.
   */
  type Set = Int => Boolean

  /**
   * This function tests whether a set contains a given element.
   */
  def contains(s: Set, elem: Int): Boolean = s(elem)

  def Set(elem: Int): Set = (x: Int) => x == elem

  def union(s: Set, t: Set): Set = (x: Int) => s(x) || t(x)
  def intersect(s: Set, t: Set): Set = (x: Int) => s(x) && t(x)
  def diff(s: Set, t: Set): Set = (x: Int) => s(x) && !t(x)

  def filter(s: Set, p: Int => Boolean): Set =
    (x: Int) => contains(s, x) && p(x)

  /*def forall(s: Set, p: Int => Boolean): Boolean = {
    def iter(a: Int): Boolean =
      if (contains(s, a) && !p(a)) false
      else if (a > 1000) true
      else iter(a + 1)
    iter(-1000)
  }*/
    
  def forall(s: Set, p: Int => Boolean): Boolean = {
    (-1000 to 1000).forall {
      i => !contains(s, i) || p(i)
    }
  }

  def exists(s: Set, p: Int => Boolean): Boolean =
    !forall(s, (x: Int) => !p(x))

  def map(s: Set, f: Int => Int): Set =
    (y: Int) => exists(s, x => y == f(x))

  /**
   * This function displays the contents of a set in a string.
   */
  def setToString(s: Set): String = {
    val xs = for (i <- -1000 to 1000 if contains(s, i)) yield i
    xs.mkString("{", ",", "}")
  }

  /**
   * This function prints the contents of a set on the console.
   */
  def printSet(s: Set) {
    println(setToString(s))
  }

  def main(args: Array[String]) {
    println("FunctionSets implementation:")
    val s = union(union(Set(3), Set(1)), Set(4))
    val t = union(Set(2), Set(4))
    val u = union(Set(-1000), Set(1000))
    println(contains(s, 1))
    println(contains(s, 5))
    print("s = "); printSet(s)
    print("t = "); printSet(t)
    print("u = "); printSet(u)
    print("s ^ t = "); printSet(intersect(s, t))
    print("s v t = "); printSet(union(s, t))
    print("filter: "); printSet(filter(s, x => x > 2))
    println("forall: " + forall(s, x => x > 0))
    println("forall: " + forall(u, x => x % 10 == 0))
    println("exists: " + exists(s, x => x > 2))
    print("map: "); printSet(map(s, x => x + 1))
  }
}