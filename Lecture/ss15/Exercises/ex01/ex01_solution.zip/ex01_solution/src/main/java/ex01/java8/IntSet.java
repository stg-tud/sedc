package ex01.java8;

public abstract class IntSet {
	public abstract IntSet incl(int x);

	public abstract boolean contains(int x);

	public abstract void foreach(IntOp f);

	public IntSet filter(IntBoolFunc p) {
		return filter0(p, new Empty());
	}

	public abstract IntSet filter0(IntBoolFunc f, IntSet accu);

	public IntSet intersect(final IntSet that) {
		return filter((i) -> that.contains(i));
	}


	@Override
	public String toString() {
		// It's easiest to use a StringBuilder here.
		// If we want to use a String, we'd have to lift the String variable,
		// see
		// below.
		final StringBuilder res = new StringBuilder();
		foreach((i) -> res.append(i).append(" "));
		return res.toString();
	}

	// Alternative toString implementation
	public String toString2() {
		final Var<String> res = new Var<String>("");
		foreach((i) -> res.set(res.get() + i + " "));
		return res.get();
	}
	
	public static void main(String[] args) {
		System.out.println("Java8 IntSet implementation:");
		System.out.println(new Empty().incl(1).incl(3).toString());
	}
}

// We could make this a singleton
class Empty extends IntSet {
	public boolean contains(int x) {
		return false;
	}

	public IntSet incl(int x) {
		return new NonEmpty(x, new Empty(), new Empty());
	}

	public void foreach(IntOp f) {
	}

	public IntSet filter0(IntBoolFunc f, IntSet accu) {
		return accu;
	}
}

class NonEmpty extends IntSet {
	// could make this private and use a getter here
	public final int elem;
	public final IntSet left, right;

	public NonEmpty(int elem, IntSet left, IntSet right) {
		this.elem = elem;
		this.left = left;
		this.right = right;
	}

	public boolean contains(int x) {
		if (x < elem)
			return left.contains(x);
		else if (x > elem)
			return right.contains(x);
		else
			return true;
	}

	public IntSet incl(int x) {
		if (x < elem)
			return new NonEmpty(elem, left.incl(x), right);
		else if (x > elem)
			return new NonEmpty(elem, left, right.incl(x));
		else
			return this;
	}

	public void foreach(IntOp f) {
		left.foreach(f);
		f.apply(elem);
		right.foreach(f);
	}

	public IntSet filter0(IntBoolFunc f, IntSet accu) {
		return right.filter0(f,
				left.filter0(f, f.apply(elem) ? accu.incl(elem) : accu));
	}
}

// We could come up with a generic interface Func<Arg, Res> for the following
// two SAM interfaces,
// but that would complicate things a little, since we have to deal with Void
// then.
interface IntOp {
	void apply(int i);
}

interface IntBoolFunc {
	boolean apply(int i);
}

// Only used for alternative toString implementation
class Var<T> {
	private T t;

	Var(T t) {
		this.set(t);
	}

	public T get() {
		return t;
	}

	public void set(T t) {
		this.t = t;
	}
}