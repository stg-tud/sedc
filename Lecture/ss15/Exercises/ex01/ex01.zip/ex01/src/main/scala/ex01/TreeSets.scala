package ex01

object TreeSets {

  abstract class IntSet {
    def incl(x: Int): IntSet
    def contains(x: Int): Boolean

    def foreach(f: Int => Unit)
    def filter(p: Int => Boolean): IntSet = ???
    def intersect(that: IntSet): IntSet = ???
    
    override def toString: String = {
      ???
    }
  }

  case object Empty extends IntSet {
    def contains(x: Int): Boolean = ???
    def incl(x: Int): IntSet = ???
    def foreach(f: Int => Unit) { ??? }
  }


  case class NonEmpty(elem: Int, left: IntSet, right: IntSet) extends IntSet {
    def contains(x: Int): Boolean = ???
      
    def incl(x: Int): IntSet = ???

    def foreach(f: Int => Unit) {
      ???
    }
  }

  // incl and contains as functions:
  def incl(s: IntSet, x: Int): IntSet = ???

  def contains(s: IntSet, x: Int): Boolean = ???

  def main(args: Array[String]) {
    println("TreeSets implementation:")
    
    // add main implementation here, can be run with sbt run
  }
}

