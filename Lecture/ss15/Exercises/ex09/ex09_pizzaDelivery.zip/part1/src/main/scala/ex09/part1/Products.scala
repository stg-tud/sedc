package ex09.part1

import Price._

/**
 * The base trait for all items that can be ordered in the store.
 */
trait Product {
  def name: String
  def price: Price
  def accept(v: ProductVisitor)
}

trait Pizza // extends ...

// TODO: implement hierarchy