package ex09.part1

object PizzaTest extends App {
  // TODO: implement 3 test cases
}