package ex09

object PizzaTest extends App {
  def printReceipt(order: Order, client: String, id: Int) {
    val v = new ReceiptVisitor(client, id)
    order.invoke(v)
    println(v.result)
    println()
  }

  printReceipt(Order(), "Joe M. T.", 0)
  printReceipt(Order(PizzaMargherita, HawaiianPizza, Water, Wine), "Mai Thai", 1)
  printReceipt(Order(FamilyPizza(SalamiPizza + Cheese + Cheese + Salami + Ham), Mug, Shirt), "Don V. Corleone", 666)
}