package ex09

import Price._

class ReceiptVisitor(client: String, order: Int) extends ProductVisitor {
  private val buf = new StringBuilder("Client: " + client + " --- order no. " + order).append("\n---------------------------------------")
  private var hasAlcohol = false
  private var startToppings = false
  private var price: Price = 0 eur 0
  private var calories = 0
  
  lazy val result: String = {
    buf.append("\n---------------------------------------\n")
    buf.append("Total: ").append(price.toString).append("     (").append(calories).append("kcal)\n")
    if (hasAlcohol) buf.append("\n#####################################\n VERIFY AGE, order contains alcohol!\n#####################################")
    buf.toString
  }

  def startVisit(p: Pizza) {
    price += p.price
    calories += p.calories
    buf.append('\n').append(p.name)
    startToppings = true
  }
  def endVisit(p: Pizza) {
    if (!startToppings) buf.append(")")
    else startToppings = false
    buf.append(" (").append(p.calories).append("kcal)   ").append(p.price)
  }
  def visit(p: Topping) {
    if (startToppings) buf.append(" (")
    startToppings = false
    buf.append("+").append(p.name)
  }
  def visit(d: Drink) {
    price += d.price
    calories += d.calories
    if (d.isAlcoholic) hasAlcohol = true
    buf.append('\n').append(d.name).append(" (").append(d.calories).append("kcal)   ").append("   ").append(d.price)
  }
  def visit(p: FranchiseProduct) {
    price += p.price
    buf.append('\n').append(p.name).append("   ").append(p.price)
  }
}
