package ex09.part2

/**
 * A builder that helps building correctly indented source code.
 * 
 * This builder maintains a current level of indentation `l`.
 * Every append method of this builder makes sure that if a new line 
 * is started (either by method `newline` or by appending a string that ends with `\n`) 
 * it starts with `l` copies of the given `indentPrefix`.   
 */
class SourceCodeBuilder(indentPrefix: String) {
  private[this] val buf = new StringBuilder()
  private[this] var ind = 0

  /**
   * Increases the level of indentation by 1.
   */
  def indent() {
    ind += 1
    if (buf.last != '\n') newline()
  }
  
  /**
   * Decreases the level of indentation by 1.
   */
  def unindent() {
    if (buf.isEmpty) throw new IllegalStateException("Cannot unindent empty buffer.")
    ind -= 1
    if (buf.last != '\n') newline()
  }

  private[this] def appendIndent() {
    for (_ <- 1 to ind) buf append indentPrefix
  }

  private[this] def checkIndent() {
    if (buf.isEmpty || buf.last == '\n') appendIndent()
  }

  /**
   * Append the given string.
   */
  def +=(str: String): this.type = {
    checkIndent()
    buf append str
    this
  }

  /**
   * Append the given integer
   */
  def +=(n: Int): this.type = {
    checkIndent()
    buf append n
    this
  }

  /**
   * Append the given double
   */
  def +=(n: Double): this.type = {
    checkIndent()
    buf append n
    this
  }

  /**
   * Start a new line.
   */
  def newline(): this.type = {
    buf append '\n'
    this
  }
  
  def isEmpty = buf.isEmpty

  /**
   * Returns the code which was built until now as a string.
   */
  def result: String = buf.toString
}