package ex09.part2

import java.net.URL
import javax.imageio.ImageIO
import java.io.IOException
import java.awt.image.BufferedImage
import java.io.File
import java.io.ByteArrayOutputStream
import java.awt.GraphicsEnvironment
import java.util.Base64

object Image {
  def apply(url: URL, width: Int, height: Int): Image = new RemoteImage(url, width, height)
  def apply(file: File): Image = new LocalImage(ImageIO.read(file))

  private[ex09] def encodeBase64(array: Array[Byte]): String = {
    val encoder = Base64.getEncoder
    encoder.encodeToString(array)
  }

  def config = GraphicsEnvironment.getLocalGraphicsEnvironment
    .getDefaultScreenDevice.getDefaultConfiguration
    
  def resizeImage(image: BufferedImage, width: Int, height: Int): BufferedImage = {
    val res = Image.config.createCompatibleImage(width, height)
    val gfx = res.createGraphics()
    gfx.drawImage(image, 0, 0, width, height, null)
    gfx.dispose()
    res
  }
}

/**
 * Represents an image with a width and height. Image data can be exported
 * to a PNG byte array.
 */
trait Image {
  /**
   * The width of this image
   */
  def width: Int

  /**
   * The height of this image
   */
  def height: Int

  /**
   * Creates a byte array that contains this image in the PNG format. May throw an
   * exception if the image data cannot be accessed.
   */
  def toPNG: Array[Byte]
}

/**
 * Image adapter to AWT buffered images, which are stored in memory.
 */
class LocalImage(image: BufferedImage) extends Image {
  def width = image.getWidth
  def height = image.getHeight

  def toPNG: Array[Byte] = {
    val out = new ByteArrayOutputStream
    ImageIO.write(image, "png", out)
    out.toByteArray()
  }
}

/**
 * Proxy to an image at the given URL. Loads image data only when needed.
 */
class RemoteImage(val url: URL, val width: Int, val height: Int) extends Image {
  // lazy vals are initialized when first accessed, i.e., we load image 
  // data only when needed here (e.g., in toPNG). 
  private lazy val image: Image = 
    new LocalImage(Image.resizeImage(ImageIO.read(url), width, height))

  def toPNG: Array[Byte] = image.toPNG
}