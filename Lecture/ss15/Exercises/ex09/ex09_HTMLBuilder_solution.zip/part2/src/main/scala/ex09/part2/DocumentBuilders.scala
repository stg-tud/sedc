package ex09.part2

import java.net.URL
import scala.collection.mutable.ArrayBuffer

trait DocumentBuilder[Result] {
  def headline(level: Int, title: String)
  def linebreak()
  def link(url: URL, text: String)
  def text(str: String)
  def canvas(width: Int, height: Int)(draw: Canvas => Unit) 
  def image(image: Image)
  def result: Result
}


class SimpleDocumentBuilder(val html: HTMLBuilder) extends DocumentBuilder[String] {
  def headline(level: Int, title: String) {
    html.addElement("h" + level, "", title)
    html.wrap()
  }
  def linebreak() {
    html.addTag("br", "")
    html.wrap()
  }
  def link(url: URL, text: String) {
    html.addElement("a", "href=\"" + url.toString + "\"", text)
  }
  def text(str: String) {
    html.addPlainText(str)
  }
  
  def image(image: Image) = html.image(image)
  
  def canvas(width: Int, height: Int)(draw: Canvas => Unit) = html.canvas(width, height)(draw)
  
  def result: String = html.result
}

class PaginatedDocumentBuilder(val newHTML: ()=>HTMLBuilder) extends DocumentBuilder[Seq[String]] {
  private val pages = new ArrayBuffer[SimpleDocumentBuilder]

  private def page = {
    if(pages.isEmpty) pages += new SimpleDocumentBuilder(newHTML())
    pages.last
  }

  def headline(level: Int, title: String) {
    if (level == 1) pages += new SimpleDocumentBuilder(newHTML())
    page.headline(level, title)
  }
  def linebreak() = page.linebreak()
  def link(url: URL, text: String) = page.link(url, text)
  def text(str: String) = page.text(str)
  
  def image(image: Image) = page.image(image)
  def canvas(width: Int, height: Int)(draw: Canvas => Unit) = page.canvas(width, height)(draw)
  
  
  def result: Seq[String] = {
    pages map { _.result }
  }
}



