package ex09.part2

/* 
 *  Comment on Task 8: Adapter Pattern:
 *    Do traits help implementing the adapter design pattern?
 *    
 *    Yes, traits do help to implement the adapter design pattern (class adapter).
 *    Since they introduce multiple inheritance, it is possible to build
 *    more powerful adapters by overwrite the methods of multiple traits or
 *    one class and multiple traits. Therefore, we get more possibilities to also build
 *    combining class adapters.
 */

abstract class HTMLBuilder {
  protected val code = new SourceCodeBuilder("  ")

  addHeader()

  protected def addHeader()
  protected def addFooter()

  def addElement(tag: String, attributes: String, content: String) {
    addTag(tag, attributes)
    code += content += "</" += tag += ">"
  }

  def addTag(tag: String, attributes: String) {
    code += "<" += tag 
    if (attributes != "") code += " " += attributes 
    code += ">"
  }
  def addPlainText(text: String) {
    code += text
  }
  def wrap() {
    code.newline()
  }
  
  def canvas(width: Int, height: Int)(draw: Canvas => Unit)

  def image(image: Image) {
    image match {
      case image: RemoteImage => 
        addTag("img", "src=\"" + image.url + "\"")
      case image: LocalImage => 
        addTag("img", "src=\"data:image/png;base64," + Image.encodeBase64(image.toPNG) + "\"")
    }
  }
  
  def result: String = {
    addFooter()
    code.result
  }
}

class HTML5Builder extends HTMLBuilder {
  protected def addHeader() {
    code += "<!DOCTYPE HTML>\n"
    code += "<html>"
    code.indent()
    code += "<head></head>\n"
    code += "<body>\n"
    code.indent()
  }
  
  protected def addFooter() {
    code.unindent()
    code += "</body>"
    code.unindent()
    code += "</html>"
    code.result
  }
  
  def canvas(width: Int, height: Int)(draw: Canvas => Unit) {
    val c = new HTML5Canvas(width, height, code)
    draw(c)
    code.newline()
    c.close()
  }
}

class HTML4StrictBuilder extends HTMLBuilder {
  protected def addHeader() {
    code += "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01//EN\" \"http://www.w3.org/TR/html4/strict.dtd\">\n"
    code += "<html>"
    code.indent()
    code += "<head></head>\n"
    code += "<body>\n"
    code.indent()
  }
  
  protected def addFooter() {
    code.unindent()
    code += "</body>"
    code.unindent()
    code += "</html>"
    code.result
  }
  
  def canvas(width: Int, height: Int)(draw: Canvas => Unit) {
    val c = new PNGCanvas(width, height, this)
    draw(c)
    c.close()
  }
}



