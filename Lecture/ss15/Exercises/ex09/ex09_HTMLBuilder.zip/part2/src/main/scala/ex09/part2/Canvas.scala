package ex09.part2

import java.awt.GraphicsEnvironment
import java.io.ByteArrayOutputStream
import javax.imageio.ImageIO

object Color {
  val Black = Color(0, 0, 0)
  val White = Color(255, 255, 255)
  val Red = Color(255, 0, 0)
  val Blue = Color(0, 0, 255)
  val Green = Color(0, 255, 0)
  
  def comp2Double(c: Int): Double = c/255d
}

case class Color(r: Int, g: Int, b: Int, a: Int = 255) {
  def withAlpha(newAlpha: Int): Color = new Color(r, g, b, newAlpha)
}

/*
 * \TODO:
 * HINT: If you need do decode BASE64, use google's guava library, it is in the dependencies.
 * \TODO
 */
trait Canvas {
  def width: Int
  def height: Int

  def setColor(c: Color)
  def drawLine(x0: Double, y0: Double, x1: Double, y1: Double)
  def fillRectangle(x: Double, y: Double, w: Double, h: Double)
  
  // You do not have to implement ellipses!
  //def fillEllipse(x: Double, y: Double, w: Double, h: Double)
  
  /**
   * Closes this canvas, i.e., all html elements will eventually be emitted 
   * after a call to this method.
   */
  def close()
}

object Canvas {
  private var i = 0
  def uniqueId(prefix: String): String = {
    i += 1
    if (!prefix(0).isLetter) throw new IllegalArgumentException("Prefix must start with a letter")
    prefix + i
  }
}

/**
 * A canvas that builds HTML 5 canvas code.
 */
class HTML5Canvas(val width: Int, val height: Int, code: SourceCodeBuilder) extends Canvas {
  private val id = Canvas.uniqueId("canvas")
  
  code += "<canvas id=\"" += id += "\" width=\"" += width += "\" height=\"" += height += "\"></canvas>\n"
  
    // TODO: implement
}

/**
 * A canvas that builds a placeholder div.
 */
class NullCanvas(val width: Int, val height: Int, code: SourceCodeBuilder) extends Canvas {
  def setColor(c: Color) {}
  def drawLine(x0: Double, y0: Double, x1: Double, y1: Double) {}
  def fillRectangle(x: Double, y: Double, w: Double, h: Double) {}
  //def fillEllipse(x: Double, y: Double, w: Double, h: Double) {}
  
  def close() = code += "<div>No image here.</div>"
}

/**
 * A canvas that renders into a PNG image.
 */
class PNGCanvas(val width: Int, val height: Int, html: HTMLBuilder) extends Canvas {
  private val image = Image.config.createCompatibleImage(width, height)
  private val gfx = image.createGraphics
  gfx.setBackground(java.awt.Color.white)
  gfx.clearRect(0, 0, width, height)

 
  // TODO: implement
}