package ex09.part2

abstract class HTMLBuilder {
  protected val code = new SourceCodeBuilder("  ")

  addHeader()

  protected def addHeader()
  protected def addFooter()

  def addElement(tag: String, attributes: String, content: String) {
    addTag(tag, attributes)
    code += content += "</" += tag += ">"
  }

  def addTag(tag: String, attributes: String) {
    code += "<" += tag 
    if (attributes != "") code += " " += attributes 
    code += ">"
  }
  def addPlainText(text: String) {
    code += text
  }
  def wrap() {
    code.newline()
  }
  
  def result: String = {
    addFooter()
    code.result
  }
}

class HTML5Builder extends HTMLBuilder // TODO: implement

class HTML4StrictBuilder extends HTMLBuilder // TODO: implement



