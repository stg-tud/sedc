package ex09.part2

/**
 * A builder that helps building correctly indented source code.
 * 
 * This builder maintains a current level of indentation `l`.
 * Every append method of this builder makes sure that if a new line 
 * is started (either by method `newline` or by appending a string that ends with `\n`) 
 * it starts with `l` copies of the given `indentPrefix`.   
 */
class SourceCodeBuilder(indentPrefix: String) {
  private val buf = new StringBuilder
  private var ind = 0 // level of indentation

  /**
   * Increases the level of indentation by 1.
   */
  def indent() {
    ind += 1
    if (buf.last != '\n') newline()
  }
  
  /**
   * Decreases the level of indentation by 1.
   */
  def unindent() = ???

  private def appendIndent() = ???

  private def checkIndent() {
    if (buf.isEmpty || buf.last == '\n') appendIndent()
  }

  /**
   * Append the given string.
   */
  def +=(str: String): this.type = ???

  /**
   * Append the given integer
   */
  def +=(n: Int): this.type = ???

  /**
   * Append the given double
   */
  def +=(n: Double): this.type = ???

  /**
   * Start a new line.
   */
  def newline(): this.type = ???

  /**
   * Returns the code which was built until now as a string.
   */
  def result: String = ???
}