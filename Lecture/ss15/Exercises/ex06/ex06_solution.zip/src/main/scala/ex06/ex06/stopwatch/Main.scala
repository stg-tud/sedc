package ex06
package stopwatch

import swing.{ Panel, MainFrame, SimpleSwingApplication }
import java.awt.{ Color, Graphics2D, Dimension }
import java.awt.Point
import scala.swing.Swing
import java.awt.Font
import scala.swing.event._
import rescala._
import makro.SignalMacro.{ SignalM => Signal }
import rescala.events._
import Time._

object Main extends ReactiveSwingApp {
  def top = new MainFrame {
    title = "Stop Watch"
    
    contents = new Panel {
      val clicks = new Mouse(this).mouseReleasedE
      ticks += { _: Unit => repaint() }
      
      val evenodds = clicks.fold(-1){ (acc, e) => (acc + 1) % 2 }
      val start = evenodds.changedTo(0)
      val stop = evenodds.changedTo(1)
      
      start += { _ => println("start")}
      stop += { _ => println("stop")}
      
      val t0 = time snapshot start
      val runningTime: Signal[Time] = Signal { time() - t0() }
      val t = clicks.toggle(runningTime snapshot stop, runningTime)
      
      val later: Signal[Time] = Signal { time() + 1.nsecs }
      val trueOrFalse: Signal[Boolean] = Signal { time() < later() }
      
      val lifeSign = {
        val temp = ticks.fold(0) { (acc, res) => (acc + 1) % 80 } 
        Signal { temp() < 40 }
      }
      
      preferredSize = new Dimension(400, 200)
      
      override def paintComponent(g: Graphics2D) {
        super.paintComponent(g)
        if(lifeSign.get) {
          g.setColor(Color.RED)
          g.fillOval(bounds.width-20, 10, 10, 10)
        }
        g.setColor(Color.BLACK)
        g.setFont(g.getFont.deriveFont(18.0f))
        g.drawString("Click mouse to start/stop the time.", 10, 25)
        g.setFont(g.getFont.deriveFont(32.0f))
        g.drawString("Time: " + t.get.inSecs, 10, 80)
        g.setFont(g.getFont.deriveFont(18.0f))
        g.drawString("This should always be true: -> " + trueOrFalse.get, 10, 150)
      }
    }
  }
}
