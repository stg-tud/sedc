package ex06

import scala.swing.Swing
import scala.swing.SimpleSwingApplication
import rescala._
import rescala.events._
import makro.SignalMacro.{SignalM => Signal}
import Time._

/**
 * Utility class to run REScala applications on the Swing thread.
 */
abstract class ReactiveSwingApp extends SimpleSwingApplication with App {
  val ticks: Event[Unit] = new ImperativeEvent[Unit] { impevent =>
    val timer = new javax.swing.Timer(20, new java.awt.event.ActionListener {
      def actionPerformed(e: java.awt.event.ActionEvent) {
        impevent.apply()
      }
    })
    timer.start()
  }

  def time: Signal[Time] = Signal { _time() }

  private var _time = Var(0 msecs)
  private val timer = new javax.swing.Timer(20, new java.awt.event.ActionListener {
    private var t0 = -1L
    def actionPerformed(e: java.awt.event.ActionEvent) {
      // Initialize t0 here, since the first event sometimes takes a while to get through the Swing queue.
      // This simply reduces stutter. 
      if (t0 < 0) t0 = e.getWhen
      val t = e.getWhen - t0
      _time()= t msecs
    }
  })
  timer.start()

  override def main(args: Array[String]) = {
    Swing.onEDT { super[App].main(args) }
    super[SimpleSwingApplication].main(args)
  }
}