package ex06
package pong

import swing.{ Panel, MainFrame, SimpleSwingApplication }
import java.awt.{ Color, Graphics2D, Dimension }
import java.awt.Point
import scala.swing.Swing
import java.awt.Font
import scala.swing.event._
import rescala._
import makro.SignalMacro.{ SignalM => Signal }
import rescala.events._

object Main extends ReactiveSwingApp {
  def top = new MainFrame {
    title = "Pong"
    resizable = false
    ticks += { _: Unit => repaint() }
    
    contents = new Panel {
      val ball = new Pong(ticks, new Mouse(this))

      preferredSize = new Dimension(Pong.Max_X, Pong.Max_Y)
      val scoreFont = new Font("Tahoma", java.awt.Font.PLAIN, 32)
      override def paintComponent(g: Graphics2D) {
        g.setColor(java.awt.Color.DARK_GRAY)
        g.fillOval(ball.x.get, ball.y.get, Ball.Size, Ball.Size)

        g.fill(ball.leftRacket.bounds.get)
        g.fill(ball.rightRacket.bounds.get)

        g.setColor(new Color(200, 100, 50))
        g.setFont(scoreFont)
        g.drawString(ball.score.get, Pong.Max_X / 2 - 50, 40)
      }
    }
  }
}
