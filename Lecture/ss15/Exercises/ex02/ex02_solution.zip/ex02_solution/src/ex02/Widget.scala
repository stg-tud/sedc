package ex02

import java.awt._
import java.awt.event.MouseEvent
import ex02.common.Utils

/**
 * The base trait of the widget hierarchy. It has bounds, can render itself and process mouse events.
 */
trait Widget {
  var bounds = new Rectangle(0,0,0,0)

  def render(g: Graphics2D) {}

  def handleMousePress(e: MouseEvent) {}
  def handleMouseRelease(e: MouseEvent) {}
}

trait Labeled extends Widget {
  var label: String = ""
  var labelColor: Color = Color.black

  override def render(g: Graphics2D) {
    println("render label")
    val p = Utils.centerStringInRectangle(g, label, bounds)
    g.setColor(labelColor)
    g.drawString(label, p.x, p.y)
    super.render(g)
  }
}

trait Bordered extends Widget {
  var borderColor: Color = Color.black

  override def render(g: Graphics2D) {
    println("render border")
    g.setColor(borderColor)
    g.drawRect(bounds.x, bounds.y, bounds.width, bounds.height)
    super.render(g)
  }
}

trait Shaded extends Widget {
  var shade: Color = new Color(220,220,250)

  override def render(g: Graphics2D) {
    println("render shade")
    g.setColor(shade)
    g.fillRect(bounds.x, bounds.y, bounds.width, bounds.height)
    super.render(g)
  }
}

trait Clickable extends Widget {
  protected var pressed = false

  override def handleMousePress(e: MouseEvent) {
    pressed = true
    super.handleMousePress(e)
  }
  override def handleMouseRelease(e: MouseEvent) {
    pressed = false
    println("Clicked")
    super.handleMouseRelease(e)
  }
}

trait Toggleable extends Widget {
  protected var on = false

  override def handleMousePress(e: MouseEvent) {
    super.handleMousePress(e)
  }
  override def handleMouseRelease(e: MouseEvent) {
    on = !on
    println("Clicked")
    super.handleMouseRelease(e)
  }
}




class Button(labelInit: String) extends Widget with Labeled with Bordered with Shaded with Clickable {
  label = labelInit

  override def render(g: Graphics2D) {
    super.render(g)
    if (pressed) {
      println("render pressed")
      Utils.hightlightRectangle(g, bounds)
    } else {
       println("render unpressed")
    }
  }
}

object ButtonTest extends Testbed {
  def newWidget() = new Button("Hello")
}

class Checkbox extends Widget with Toggleable with Bordered with Shaded  {
  override def render(g: Graphics2D) {
    super.render(g)
    if (on) {
      println("render checkmark")
      g.setColor(Color.black)
      g.drawLine(bounds.x, bounds.y, bounds.x+bounds.width, bounds.y+bounds.height)
      g.drawLine(bounds.x + bounds.width, bounds.y, bounds.x, bounds.y+bounds.height)
    }
  }
}

object CheckboxTest extends Testbed {
  def newWidget() = new Checkbox()
}

class Label(labelInit: String) extends Widget with Labeled {
  label = labelInit
}

object LabelTest extends Testbed {
  def newWidget() = new Label("Hello")
}