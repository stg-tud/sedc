package ex02.java7;

import java.awt.*;
import java.awt.event.MouseEvent;

public class Toggleable extends DecoratedWidget {
  protected boolean on = false;

  public Toggleable(Widget delegate) {
    super(delegate);
  }

  public void handleMousePress(MouseEvent e) {
    super.handleMousePress(e);
  }

  public void handleMouseRelease(MouseEvent e) {
    on = !on;
    System.out.println("Clicked");
    super.handleMouseRelease(e);
  }

  @Override
  public void render(Graphics2D g) {
    if (on) {
      System.out.println("render checkmark");
      g.setColor(Color.black);
      Rectangle bounds = getBounds();
      g.drawLine(bounds.x, bounds.y, bounds.x + bounds.width, bounds.y + bounds.height);
      g.drawLine(bounds.x + bounds.width, bounds.y, bounds.x, bounds.y + bounds.height);
    }
    super.render(g);
  }
}
