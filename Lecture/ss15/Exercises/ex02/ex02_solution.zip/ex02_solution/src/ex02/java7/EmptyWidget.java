package ex02.java7;

import java.awt.Rectangle;

public class EmptyWidget extends Widget {
  private Rectangle bounds = new Rectangle(0,0,0,0);

  public Rectangle getBounds() {
    return bounds;
  }
  public void setBounds(Rectangle b) {
    this.bounds = b;
  }
}
