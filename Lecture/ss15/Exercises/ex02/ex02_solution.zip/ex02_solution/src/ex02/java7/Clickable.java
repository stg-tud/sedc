package ex02.java7;

import java.awt.Graphics2D;
import java.awt.event.MouseEvent;

import ex02.common.Utils;

class Clickable extends DecoratedWidget {
  protected boolean pressed = false;

  public Clickable(Widget delegate) {
    super(delegate);
  }

  @Override
  public void handleMousePress(MouseEvent e) {
    pressed = true;
    super.handleMousePress(e);
  }

  @Override
  public void handleMouseRelease(MouseEvent e) {
    pressed = false;
    System.out.println("Clicked");
    super.handleMouseRelease(e);
  }

  @Override public void render(Graphics2D g) {
    if (pressed) {
      System.out.println("render pressed");
      Utils.hightlightRectangle(g, getBounds());
    } else {
      System.out.println("render unpressed");
    }
    super.render(g);
  }
}