package ex02.java7;

public class MyWidgetTest {
  public static void main(String[] args) {
    //new Testbed(new Label("Hello"));
    //new Testbed(new Button("Hello"));
    new Testbed(new Checkbox());
  }
}

class Label extends Labeled {
  public Label(String label) {
    super(new EmptyWidget());
    this.label = label;
  }
}

class Button extends Shaded {
  public Button(String label) {
    super(new Labeled(new Bordered(new Clickable(new EmptyWidget()))));
    // this is ugly, but it gets even more ugly, if we want to do it without a cast.
    ((Labeled)delegate).label = label;
  }

  // we can't do this here easily, because we have to find the clickable in the chain of delegates
  // in order to query the pressed state.
  // Therefore, we move this to Clickable which is not really desirable though.
  // The same is true for the toggleable functionality.
  /*@Override void render(Graphics2D g) {
    super.render(g);
    if (pressed) {
      println("render pressed")
      Utils.hightlightRectangle(g, bounds)
    } else {
       println("render unpressed")
    }
  }*/
}

class Checkbox extends Shaded {
  public Checkbox() {
    super(new Bordered(new Toggleable(new EmptyWidget())));
  }
}