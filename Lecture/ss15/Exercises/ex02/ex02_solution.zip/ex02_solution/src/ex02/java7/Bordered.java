package ex02.java7;

import java.awt.*;

public class Bordered extends DecoratedWidget {
  Color borderColor = Color.black;

  public Bordered(Widget delegate) {
    super(delegate);
  }

  @Override
  public void render(Graphics2D g) {
    System.out.println("render border");
    g.setColor(borderColor);
    Rectangle b = getBounds();
    g.drawRect(b.x, b.y, b.width, b.height);
    super.render(g);
  }
}