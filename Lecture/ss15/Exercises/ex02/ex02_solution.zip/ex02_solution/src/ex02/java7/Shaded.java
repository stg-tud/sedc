package ex02.java7;

import java.awt.*;

public class Shaded extends DecoratedWidget {
  Color shade = new Color(220,220,250);

  public Shaded(Widget delegate) {
    super(delegate);
  }

  @Override public void render(Graphics2D g) {
    System.out.println("render shade");
    g.setColor(shade);
    Rectangle b = getBounds();
    g.fillRect(b.x, b.y, b.width, b.height);
    super.render(g);
  }
}