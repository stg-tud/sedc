package ex02.java7;

import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.event.MouseEvent;

public class DecoratedWidget extends Widget {
  protected final Widget delegate;

  public DecoratedWidget(Widget delegate) {
    this.delegate = delegate;
  }

  public Rectangle getBounds() {
    return delegate.getBounds();
  }
  public void setBounds(Rectangle b) {
    delegate.setBounds(b);
  }

  public void render(Graphics2D g) {
    delegate.render(g);
  }

  public void handleMousePress(MouseEvent e) {
    delegate.handleMousePress(e);
  }

  public void handleMouseRelease(MouseEvent e) {
    delegate.handleMouseRelease(e);
  }
}
