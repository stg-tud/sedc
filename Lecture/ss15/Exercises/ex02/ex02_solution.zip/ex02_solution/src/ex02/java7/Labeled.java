package ex02.java7;

import java.awt.*;

import ex02.common.Utils;

public class Labeled extends DecoratedWidget {
  String label = "";
  Color labelColor = Color.black;

  public Labeled(Widget delegate) {
    super(delegate);
  }

  @Override
  public void render(Graphics2D g) {
    System.out.println("render label");
    Point p = Utils.centerStringInRectangle(g, label, getBounds());
    g.setColor(labelColor);
    g.drawString(label, p.x, p.y);
    super.render(g);
  }
}