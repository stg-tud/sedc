package ex02.java7;

import java.awt.*;
import java.awt.event.MouseEvent;

public abstract class Widget {
  public abstract Rectangle getBounds();
  public abstract void setBounds(Rectangle b);

  public void render(Graphics2D g) {}
  public void handleMousePress(MouseEvent e) {}
  public void handleMouseRelease(MouseEvent e) {}
}