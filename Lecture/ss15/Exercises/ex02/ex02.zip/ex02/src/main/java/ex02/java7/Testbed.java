package ex02.java7;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

/**
 * The Java version of the testbed. Due the difference of object members in Scala and static members
 * in Java it is used a little differently than the Scala version. See class MyWidgetTest.
 */
public class Testbed {
  public Testbed(final Widget w) {
    SwingUtilities.invokeLater(new Runnable() {
      public void run() {
        JFrame frame = new JFrame("Widget Testbed");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(600, 400);
        Container pane = frame.getContentPane();
        pane.add(new TestComponent(w));
        frame.setVisible(true);
      }
    });
  }

  private class TestComponent extends JComponent {
    private final int gap = 20;
    private final Widget widget;

    TestComponent(Widget w) {
      this.widget = w;
      addMouseListener(new MouseAdapter() {
        private boolean down = false;

        @Override
        public void mousePressed(MouseEvent e) {
          if (widget.getBounds().contains(e.getPoint())) {
            widget.handleMousePress(e);
            down = true;
          }
          repaint();
        }

        @Override
        public void mouseReleased(MouseEvent e) {
          if (down) {
            widget.handleMouseRelease(e);
            down = false;
          }
          repaint();
        }
      });

      addComponentListener(new ComponentAdapter() {
        @Override
        public void componentResized(ComponentEvent e) {
          Rectangle b = getBounds();
          widget.setBounds(new Rectangle(gap, gap, b.width - gap * 2, b.height - gap * 2));
          repaint();
        }
      });
    }

    @Override
    protected void paintComponent(Graphics gfx) {
      Graphics2D g = (Graphics2D) gfx;
      g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
      widget.render(g);
    }
  }
}
