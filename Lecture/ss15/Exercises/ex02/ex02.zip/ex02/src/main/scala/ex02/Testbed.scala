package ex02

import javax.swing._
import java.awt._
import java.awt.event._

/**
 * The testbed to test your widget implementation.
 */
trait Testbed {
  def main(args: Array[String]) {
    SwingUtilities.invokeLater(new Runnable {
      def run() {
        val frame = new JFrame("Widget Testbed")
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE)
        frame.setSize(600, 400)
        val pane = frame.getContentPane
        pane.add(new TestComponent(newWidget()))
        frame.setVisible(true)
      }
    })
  }

  private class TestComponent(widget: Widget) extends JComponent {
    private val gap = 20

    override def paintComponent(gfx: Graphics) {
      val g = gfx.asInstanceOf[Graphics2D]
      g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON)
      widget.render(g)
    }

    addMouseListener(new MouseAdapter {
      private var down = false
      override def mousePressed(e: MouseEvent) {
        if(widget.bounds.contains(e.getPoint())) {
          widget.handleMousePress(e)
          down = true
        }
        repaint()
      }
      override def mouseReleased(e: MouseEvent) {
        if(down) {
          widget.handleMouseRelease(e)
          down = false
        }
        repaint()
      }
    })

    addComponentListener(new ComponentAdapter {
      override def componentResized(e: ComponentEvent) {
        val b = getBounds()
        widget.bounds = new Rectangle(gap, gap, b.width-gap*2, b.height-gap*2)
        repaint()
      }
    })
  }

  /**
   * This method should return your widget to test.
   */
  def newWidget(): Widget
}