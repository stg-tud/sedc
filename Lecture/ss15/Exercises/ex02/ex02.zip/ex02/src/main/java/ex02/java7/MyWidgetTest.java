package ex02.java7;

public class MyWidgetTest {
  public static void main(String[] args) {
    //new Testbed(new Checkbox());
  }
}