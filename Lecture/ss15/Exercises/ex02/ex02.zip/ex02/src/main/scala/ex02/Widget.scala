package ex02

import java.awt._
import java.awt.event.MouseEvent
import ex02.common.Utils

/**
 * The base trait of the widget hierarchy. It has bounds, can render itself and process mouse events.
 */
trait Widget {
  var bounds = new Rectangle(0,0,0,0)

  def render(g: Graphics2D) {}

  def handleMousePress(e: MouseEvent) {}
  def handleMouseRelease(e: MouseEvent) {}
}