package ex02.common;

import java.awt.*;
import java.awt.geom.Rectangle2D;

public class Utils {
  /**
   * Returns a pair or (x,y) coordinates that can be used to draw a string centered in a given
   * rectangle using Graphics2D.drawString.
   */
  public static Point centerStringInRectangle(Graphics2D g, String str, Rectangle rect) {
    FontMetrics fm = g.getFontMetrics();
    Rectangle2D b = fm.getStringBounds(str, g);
    double x = rect.x + (rect.width - b.getWidth()) / 2;
    double y = rect.y + (rect.height - b.getHeight()) / 2 + fm.getAscent();
    return new Point((int)x, (int)y);
  }

  // Note that this has an alpha value < 255, so a rectagle filled with this color will let the
  // pixels underneath shine through.
  private static final Color TranslucentWhite = new Color(255, 255, 255, 150);

  /**
   * Draws a translucent white rectangle to hightlight an area of the image/screen underlying the
   * given Graphics2D.
   */
  public static void hightlightRectangle(Graphics2D g, Rectangle r) {
    g.setColor(TranslucentWhite);
    g.fillRect(r.x, r.y, r.width, r.height);
  }
}
